os.date2 = os.date
os.date = function(str, timer)
    return os.date2(str, timer or os.time())
end

-- Support old functions
G_ServerDate = os.date