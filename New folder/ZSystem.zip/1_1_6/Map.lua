_map = {}

_map.init = function()
    if ServerTeam == 'ssemu' then
        for k,v in pairs(_data["MAPMANAGER"][-1]) do
            _map[tonumber(v[1])] = v[24]
        end
    else
        local File = io.open(table.concat({_path.data,"MapManager.txt"},"\\"), 'r')
        for line in File:lines() do
            if line:find("/") ~= 1 and line:gsub("%s",""):gsub("\t",""):len() > 0 then
                local id = line:match("(%d+)")
                local name = line:match("//(.+)")
                if id ~= nil and name ~= nil then
                    _map[tonumber(id)] = name
                end
            end
        end
    end
end

_map.id = function(name)
    for k,v in pairs(_map) do
        if type(v) == "string" and v:lower() == name:lower() then
            return k
        end
    end
    return 0
end

G_Map = _map