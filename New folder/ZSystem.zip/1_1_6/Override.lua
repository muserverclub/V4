_user.levelEx = function(aIndex)
    return GetObjectLevel(aIndex) + (Season > 2 and GetObjectMasterLevel(aIndex) or 0)
end

_user.classEx = function(aValue, bValue)
    -- aValue = User Index or Class
    -- bValue = ClassUp
    -- return full class number
    if bValue == nil then
        return (GetObjectClass(aValue) * 16) + GetObjectChangeUp(aValue)
    end

    return (class * 16) + bValue
end

_user.classNameEx = function(aValue, bValue)
    -- aValue = User Index or Class
    -- bValue = ClassUp
    -- return full class name
    if bValue == nil then
        return _class.ex[GetObjectClass(aValue) + 1][GetObjectChangeUp(aValue) + 1]
    end

    return _class.ex[aValue + 1][bValue + 1]
end

_user.hwid = function(aIndex)
    return CharacterBridge[aIndex].MEMB_INFO.hwid
end

_user.hwidSet = function(aIndex, hwid)
    CharacterBridge[aIndex].MEMB_INFO.hwid = hwid
    SQLQuery("UPDATE MEMB_INFO SET hwid = '%s' WHERE memb___id='%s'", {hwid, GetObjectAccount(aIndex)})
end

_user.auth2fa = function(aIndex)
    return CharacterBridge[aIndex].MEMB_INFO.auth2fa
end

GetObjectAccount2 = GetObjectAccount
_user.account = function(aIndex)
    if CharacterBridge[aIndex] ~= nil then
        return CharacterBridge[aIndex].MEMB_INFO.memb___id
    else
        return GetObjectAccount2(aIndex)
    end
end

-- Support old scripts
if _G["GetObjectHWID"] == nil then
    GetObjectHWID = _user.hwid
end

GetObjectAccount = _user.account

G_ClassEx = _class.ex
G_ClassName = _user.classNameEx
