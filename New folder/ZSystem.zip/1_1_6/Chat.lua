ChatTargetSend2 = ChatTargetSend

ChatTargetSend = function(aIndex, bIndex, text, param)
    if type(text) == "table" then
        local textId = bIndex == -1 and 1 or (GetObjectLang(bIndex) + 1)
        text = text[textId]
    end

    ChatTargetSend2(aIndex, bIndex, string.format(text, unpack(param or {})))
end
