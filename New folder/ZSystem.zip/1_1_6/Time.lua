os.time2 = os.time

_time.count = os.time()
os.time2 = os.time
os.time = function(arg)
    if arg ~= nil then
        return os.time2(arg)
    end
    return _time.count
end

_time.start = function(aValue)
    local time = os.date("*t")

    if aValue.year == nil or table.find(aValue.year, {time.year, false}) ~= -1 then
        if aValue.month == nil or table.find(aValue.month, {time.month, false}) ~= -1 then
            if aValue.day == nil or table.find(aValue.day, {time.day, false}) ~= -1 then
                if aValue.wday == nil or table.find(aValue.wday, {time.wday, false}) ~= -1 then
                    if aValue.hour == nil or table.find(aValue.hour, {time.hour, false}) ~= -1 then
                        if aValue.min == nil or table.find(aValue.min, {time.min, false}) ~= -1 then
                            if aValue.sec == nil or table.find(aValue.sec, {time.sec, false}) ~= -1 then
                                return 1
                            end
                        end
                    end
                end
            end
        end
    end

    return 0
end

_time.startMult = function(aValue)
    for k, v in pairs(aValue) do
        if _time.start(v) ~= 0 then
            return 1
        end
    end

    return 0
end

_time.random = function(time)
    return os.time() + math.random(time)
end

_time.toDate = function(t)
    local days = math.floor(t / 86400)
    local hours = math.floor(t % 86400 / 3600)
    local minutes = math.floor(t % 3600 / 60)
    local seconds = math.floor(t % 60)
    return ("%d %02d:%02d:%02d"):format(days, hours, minutes, seconds)
end

_time.format = function(aValue)
    local days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}

    local year = ""
    local month = ""
    local day = ""
    local wday = ""
    local hour = ""
    local min = ""
    local sec = ""

    if aValue.year ~= nil and aValue.year ~= false then
        year = aValue.year
    end

    if aValue.month ~= nil and aValue.month ~= false then
        month = aValue.month
    end

    if aValue.day ~= nil and aValue.day ~= false then
        day = aValue.day
    end

    if aValue.wday ~= nil and aValue.wday ~= false then
        wday = days[aValue.wday]
    end

    if aValue.hour ~= nil and aValue.hour ~= false then
        hour = aValue.hour
    end

    if aValue.min ~= nil and aValue.min ~= false then
        min = aValue.min
    end

    if aValue.sec ~= nil and aValue.sec ~= false then
        sec = aValue.sec
    end

    return ("%s %s/%s/%s as %s:%s:%s"):format(wday, day, month, year, hour, min, sec)
end

_time.diff = function(fim, time)
    if time == nil then
        time = os.time()
    end

    return fim - os.time()
end

_time.week = function()
    local weekTime = 86400 * 7

    local count = 0

    local startDate = os.time({year = os.date("*t").year - 1, month = 13, day = 1, hour = 0, min = 0, sec = 0})
    local currentDate = G_ServerTime()

    while 1 do
        if currentDate < startDate then
            break
        else
            currentDate = currentDate - weekTime
            count = count + 1
        end
    end

    return count
end

-- Support to old functions
G_ServerTime = os.time
G_TimeStart = _time.start
G_TimeStartMult = _time.startMult
G_TimeRandom = _time.random
G_Time_SecondToDate = _time.toDate
G_TimeFormat = _time.format
G_TimeDiff = _time.diff
GetWeekNumber = _time.week
