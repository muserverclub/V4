

_coin.check = function(aIndex, lance, Type, level)
  if Season > 3 then
      local WCC, WCP, WGP = CashShopGetPoint(aIndex)
      if Type == 10000 and tonumber(WCC) < lance then
          return 0
      end
      if Type == 10001 and tonumber(WCP) < lance then
          return 0
      end
      if Type == 10002 and tonumber(WGP) < lance then
          return 0
      end
  end
  if Type == 10003 and GetObjectMoney(aIndex) < lance then
      return 0
  end
  if Season > 9 then
      if Type == 10004 and GetObjectRuud(aIndex) < lance then
          return 0
      end
  end
  if Type == 10005 then
      SQLQuery(string.format(lance.Check, lance.Type == 0 and GetObjectAccount(aIndex) or GetObjectName(aIndex)))
      if SQLFetch() == 0 then
          SQLClose()
          return 0
      end
      SQLClose()
  end
  if Type < 10000 and InventoryGetItemCount(aIndex, Type, level) < lance then
      return 0
  end

  return 1
end

_coin.sub = function(aIndex, lance, Type, level)
  if Season > 3 then
      if Type == 10000 then
          CashShopSubPoint(aIndex, lance, 0, 0)
      end
      if Type == 10001 then
          CashShopSubPoint(aIndex, 0, lance, 0)
      end
      if Type == 10002 then
          CashShopSubPoint(aIndex, 0, 0, lance)
      end
  end
  if Type == 10003 then
      local money = GetObjectMoney(aIndex) - lance
      SetObjectMoney(aIndex, money)
      MoneySend(aIndex, money)
  end
  if Season > 9 then
      if Type == 10004 then
          local ruud = GetObjectRuud(aIndex) - lance
          SetObjectRuud(aIndex, ruud)
          RuudSend(aIndex, ruud)
      end
  end
  if Type == 10005 then
      SQLQuery(string.format(lance.Remove, lance.Type == 0 and GetObjectAccount(aIndex) or GetObjectName(aIndex)))
      SQLClose()
  end
  if Type < 10000 then
      InventoryDelItemCount(aIndex, Type, level, lance)
  end
end

-- support old functions
G_Coin = _coin.name
G_CoinCheck = _coin.check
G_CoinSub = _coin.sub