table.pack = function(...)
    return {n = select("#", ...), ...}
end

table.parse = function(data)
    if string.find(data, "return") == nil then
        return nil
    end
    return loadstring(data)()
end

table.stringify = function(o, addreturn, format, rep)
    rep = rep or 0
    if type(o) == "table" then
        local s = ""
        if addreturn == true then
            s = s .. "return "
        end
        if format == true then
            s = s .. "{\n"
        else
            s = s .. "{"
        end
        for k, v in pairs(o) do
            if type(k) ~= "number" then
                k = '"' .. k .. '"'
            end
            if format == true then
                s =
                    s ..
                    string.rep("\t", rep + 1) .. "[" .. k .. "]=" .. table.stringify(v, false, format, rep + 1) .. ",\n"
            else
                s = s .. "[" .. k .. "]=" .. table.stringify(v, false, format, rep + 1) .. ","
            end
        end
        if format == true then
            return s .. string.rep("\t", rep) .. "}"
        else
            return s .. "}"
        end
    else
        if tonumber(o) == nil then
            return '"' .. o .. '"'
        end
        return o
    end
end

table.print = function(tab, file, format)
    local open = io.open(file, "w")
    if open ~= nil then
        open:write(table.stringify(tab, true, format or false))
        open:close()
        return true
    end
    return false
end

table.read = function(file)
    local open = io.open(file, "r")
    if open ~= nil then
        local read = loadstring(open:read("*all"))()
        open:close()
        return read
    end
    return nil
end

table.count = function(T)
    local count = 0
    for _ in pairs(T) do
        count = count + 1
    end
    return count
end

table.serialize = function(arg)
    local serialized = ""
    for key, value in pairs(arg) do
        serialized = serialized .. "|" .. key .. "="
        if type(value) == "table" then
            for ke, val in pairs(value) do
                serialized = serialized .. ";" .. ke .. "="
                if type(val) == "table" then
                    for k, v in pairs(val) do
                        serialized = serialized .. ":" .. k .. "=" .. v .. ":"
                    end
                else
                    serialized = serialized .. val
                end
                serialized = serialized .. ";"
            end
        else
            serialized = serialized .. value
        end
        serialized = serialized .. "|"
    end
    return serialized
end

table.unserialize = function(arg)
    local unserialized = {}

    for value in arg:gmatch("|([^|]*)|") do
        local key1 = table.unserialize_key(value)
        unserialized[key1] = {}
        if value.find(value, ";([^;]*);") then
            for val in value:gmatch(";([^;]*);") do
                local key2 = table.unserialize_key(val)
                unserialized[key1][key2] = {}
                if value.find(val, ":([^:]*):") then
                    for v in val:gmatch(":([^:]*):") do
                        unserialized[key1][key2][table.unserialize_key(v)] = table.unserialize_result(v)
                    end
                else
                    unserialized[key1][key2] = table.unserialize_result(val)
                end
            end
        else
            unserialized[key1] = table.unserialize_result(value)
        end
    end

    return unserialized
end

table.unserialize_key = function(arg)
    for key in arg:gmatch("(-?%w*)=") do
        return tonumber(key) == nil and key or tonumber(key)
    end
end

table.unserialize_result = function(arg)
    for result in arg:gmatch("=(.*)") do
        return tonumber(result) == nil and result or tonumber(result)
    end
end

table.find = function(aValue, bValue)
    local inarray = -1

    for index, value in pairs(bValue) do
        if tonumber(aValue) ~= nil and tonumber(value) ~= nil then
            if tonumber(value) == tonumber(aValue) then
                inarray = index
                break
            end
        else
            if value == aValue then
                inarray = index
                break
            end
        end
    end

    return inarray
end

table.reverse = function(tab)
    local ret = {}
    for i = #tab, 1, -1 do
        table.insert(ret, tab[i])
    end
    return ret
end

table.order = function(tab, func)
    local spairs = function(t, order)
        -- collect the keys
        local keys = {}
        for k in pairs(t) do
            keys[#keys + 1] = k
        end

        -- if order function given, sort by it by passing the table and keys a, b,
        -- otherwise just sort the keys
        if order then
            table.sort(
                keys,
                function(a, b)
                    return order(t, a, b)
                end
            )
        else
            table.sort(keys)
        end

        -- return the iterator function
        local i = 0
        return function()
            i = i + 1
            if keys[i] then
                return keys[i], t[keys[i]]
            end
        end
    end

    local order = {}

    for k, v in spairs(tab, func) do
        table.insert(order, v)
    end

    return order

    -- example
    --[[
  for k,v in spairs(tab, function(t,a,b) return t[b][2] > t[a][2] end) do
      print(unpack(v))
  end
  ]]
end

table.clone = function(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == "table" then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[table.clone(orig_key)] = table.clone(orig_value)
        end
        setmetatable(copy, table.clone(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

-- Support to old functions
G_serialize = table.serialize
G_unserialize = table.unserialize
G_CountTable = table.count
G_InArray = table.find
printTable = table.print
R_CloneTable = table.clone
