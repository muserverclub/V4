BridgeOrder = {
	"Bridge",
	"HuntPoint",
	"Battle"
}

SetBridgeTab = function(tab, type)
	local ntab = table.clone(tab)
	local ord = {}

	for k, v in pairs(BridgeOrder) do
		for i, a in pairs(ntab) do
			if (tostring(type == nil and a.Function or a):find(v)) == 1 then
				table.remove(ntab, i)
				table.insert(ord, a)
			end
		end
	end

	local findF = function(f)
		for k, v in pairs(ord) do
			if tostring(type == nil and v.Function or a) == f then
				return 1
			end
		end
		return 0
	end

	for i, a in pairs(ntab) do
		if findF(tostring(type == nil and a.Function or a)) == 0 then
			table.insert(ord, a)
		end
	end

	return ord
end

SetBridgeOrder = function(tab, type)
	return SetBridgeTab(tab, type)
end

SetBridgeOrderReverse = function(tab, type)
	return table.reverse(SetBridgeTab(tab, type))
end
