NoticeSend2 = NoticeSend
NoticeSendToAll2 = NoticeSendToAll
NoticeRegionSend2 = NoticeRegionSend
NoticeGlobalSend2 = NoticeGlobalSend
NoticeLangSendToAll2 = NoticeLangSendToAll
NoticeLangRegionSend2 = NoticeLangRegionSend
NoticeLangGlobalSend2 = NoticeLangGlobalSend

NoticeLang = function(level,eng,por,spn)

	if level < 20 then
		NoticeLangSendToAll2(level-10,eng,por,spn)
	elseif level < 30 then
		NoticeLangRegionSend2(level-20,eng,por,spn)
	elseif level < 40 then
		NoticeLangGlobalSend2(level-30,eng,por,spn)
	end

end

NoticeMake = function(level, eng, por, spn)
    if  type(level) == 'table' then 
        if eng == nil then eng = {} end
        return level[4],string.format(level[1],unpack(eng)),string.format(level[2],unpack(eng)),string.format(level[3],unpack(eng))
    else return level,eng,por,spn end
end

NoticeSend = function(aIndex,level,arg)
    local level,eng,por,spn = NoticeMake(level,arg,arg,arg)

	if level < 100 then NoticeSend2(aIndex,level%10,eng) end
end

NoticeSendToAll = function(level,arg)
    local level,eng,por,spn = NoticeMake(level,arg,arg,arg)

    if level < 10 then
		NoticeSendToAll2(level,eng)
	else
        NoticeLang(level,eng,por,spn)
    end
end
NoticeRegionSend = function(level,arg)
    local level,eng,por,spn = NoticeMake(level,arg,arg,arg)    

    if level < 10 then
		NoticeRegionSend2(level,eng)
	else
        NoticeLang(level,eng,por,spn)
    end
end
NoticeGlobalSend = function(level,arg)
    local level,eng,por,spn = NoticeMake(level,arg,arg,arg)    

    if level < 10 then
		NoticeGlobalSend2(level,eng)
	else
        NoticeLang(level,eng,por,spn)
    end
end
NoticeLangSendToAll = function(level,eng,por,spn)
    local level,eng,por,spn = NoticeMake(level,eng,por,spn)

    if level < 10 then
		NoticeLangSendToAll2(level,eng,por,spn)
	else
        NoticeLang(level,eng,por,spn)
    end
end
NoticeLangRegionSend = function(level,eng,por,spn)
    local level,eng,por,spn = NoticeMake(level,eng,por,spn)

    if level < 10 then
		NoticeLangRegionSend2(level,eng,por,spn)
	else
        NoticeLang(level,eng,por,spn)
    end
end
NoticeLangGlobalSend = function(level,eng,por,spn)
    local level,eng,por,spn = NoticeMake(level,eng,por,spn)

    if level < 10 then
		NoticeLangGlobalSend2(level,eng,por,spn)
	else
        NoticeLang(level,eng,por,spn)
    end
end