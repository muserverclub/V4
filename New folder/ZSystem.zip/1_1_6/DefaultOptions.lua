-- Default Options
Server_ODBC = Server_ODBC or "MuOnline"
Server_USER = Server_USER or ""
Server_PASS = Server_PASS or ""
Season = Season or 0
ServerTeam = ServerTeam or "xteam"
ZSystemDebug = ZSystemDebug or false
API_URL = API_URL or "http://localhost:3333/"
ScriptUseServerCode = ScriptUseServerCode or 19
AdminAuthority = AdminAuthority or {}
ReloadScriptCode = ReloadScriptCode or 1001
LagDetection = LagDetection or false
BOT_LIST = BOT_LIST or {}
DisconnectOnEmptyHwid = DisconnectOnEmptyHwid or false
Path_Configs = Path_Configs or "Configs"
Path_GS = Path_GS or GetGameServerCode()

G_Event_List =
	G_Event_List or
	{
		[719] = {"BloodCastle", {11, 12, 13, 14, 15, 16, 17, 52}, false},
		[720] = {"DevilSquare", {9, 32, 102}, false},
		[721] = {"ImperialFortress", {69, 70, 71, 72}, false},
		[722] = {"IllusionTemple", {45, 46, 47, 48, 49, 50, 98, 99}, false},
		[723] = {"MirrorOfDimension", {65, 66, 67, 68, 82, 83, 84, 85, 86, 87, 88, 89, 90}, false}
	}

SQLConnect(Server_ODBC, Server_USER, Server_PASS)
SQLAsyncConnect(Server_ODBC, Server_USER, Server_PASS)

protect("_download")
