_pk = {}
_pk.list = {}

_pk.send = function(aIndex)
    _pk.list[aIndex] = {
        GetObjectPKCount(aIndex),
        GetObjectPKLevel(aIndex),
        GetObjectPKTimer(aIndex)
    }
    SetObjectPKLevel(aIndex, 7)
    SetObjectPKCount(aIndex, 7)
    SetObjectPKTimer(aIndex, 1000000)
    PKLevelSend(aIndex, 7)
end

_pk.restore = function(aIndex)
    if _pk.list[aIndex] ~= nil then
        local t = _pk.list[aIndex]
        SetObjectPKCount(aIndex, t[1])
        SetObjectPKLevel(aIndex, t[2])
        SetObjectPKTimer(aIndex, t[3])
        PKLevelSend(aIndex, t[2])
        _pk.list[aIndex] = nil
    end
end

R_PkAdd = _pk.send
R_PkRestore = _pk.restore
