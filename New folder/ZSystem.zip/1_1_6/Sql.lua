SQLQuery2 = SQLQuery
SQLQuery = function(query, params, data)
    params = params or {}
    data = data or {}
    for k, v in pairs(params) do
        params[k] = tostring(v):gsub("'", "")
    end
    local exec = SQLQuery2(query:format(unpack(params)))
    if exec == 0 then
        SQLClose()
        return 0
    end

    if table.count(data) > 0 then
        if SQLFetch() == 0 then
            SQLClose()
            return 0
        end
        local ret = {}
        for k, v in pairs(data) do
            table.insert(ret, SQLGetString(v))
        end

        SQLClose()
        return 1, unpack(ret)
    end

    if table.count(params) > 0 then
        SQLClose()
    end

    return 1
end
