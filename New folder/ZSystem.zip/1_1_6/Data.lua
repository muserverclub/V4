_data_Load = function()
    -- Custom
    G_CustomMonster = _data["CUSTOM_CUSTOMMONSTER"][-1]

    -- Ancient Option
    G_AncientOptionTable = {}
    G_AncientOption = function(aIndex)
        return G_AncientOptionTable[aIndex]
    end

    if Season > 0 then
        for k, v in pairs(_data["ITEM_SETITEMOPTION"][-1]) do
            G_AncientOptionTable[k] = v[2]
        end
    end

    -- Ancient Type
    G_AncientTypeTable = {}
    G_AncientType = function(aIndex)
        return G_AncientTypeTable[aIndex]
    end

    if Season > 0 then
        for j, a in pairs(_data["ITEM_SETITEMTYPE"][-1]) do
            G_AncientTypeTable[a[1]] = {}
            for k, v in pairs({1, 2, 16}) do
                if a[2 + k] ~= 0 then
                    for i = 0, 3, 1 do
                        local descr = i == 0 and " " or string.format(" Increase strength +%d", (i * 5))
                        local option = G_AncientOption(a[(2 + k)])
                        if option ~= nil then
                            G_AncientTypeTable[a[1]][(v + (i * 4))] = G_AncientOption(a[(2 + k)]) .. descr
                        end
                    end
                end
            end
        end
    end

    -- Excellent
    G_ExcellentTable = {}
    G_Excellent = function(aIndex)
        return G_ExcellentTable[aIndex]
    end

    G_ExcellentTable[1] = {}
    G_ExcellentTable[2] = {}
    G_ExcellentTable[4] = {}
    G_ExcellentTable[8] = {}
    G_ExcellentTable[16] = {}
    G_ExcellentTable[32] = {}

    for k, v in pairs(_data["ITEM_EXCELLENTOPTIONRATE"][-1]) do
        for i = v[2], v[3], 1 do
            G_ExcellentTable[v[1]][i] = v[4]
        end
    end

    -- Harmony
    G_HarmonyTable = {}

    G_Harmony = function(aIndex)
        local Section = math.floor(aIndex / 512)
        if Section < 5 then
            return G_HarmonyTable[1]
        elseif Section == 5 then
            return G_HarmonyTable[2]
        elseif Section < 12 then
            return G_HarmonyTable[3]
        else
            return nil
        end
    end

    if Season > 0 then
        for k, v in pairs(_data["ITEM_JEWELOFHARMONYOPTION"]) do
            G_HarmonyTable[k] = {}
            for i, a in pairs(v) do
                local Row = {}
                Row.Name = a[2]
                Row[0] = a[5]
                Row[1] = a[7]
                Row[2] = a[9]
                Row[3] = a[11]
                Row[4] = a[13]
                Row[5] = a[15]
                Row[6] = a[17]
                Row[7] = a[19]
                Row[8] = a[21]
                Row[9] = a[23]
                Row[10] = a[25]
                Row[11] = a[27]
                Row[12] = a[29]
                Row[13] = a[31]
                Row[14] = a[33]
                Row[15] = a[35]

                G_HarmonyTable[k][i] = Row
            end
        end
    end

    -- Item
    G_ItemTable = _data["ITEM_ITEM"]

    G_LoadItem = function(Index, Pos)
        if Pos == nil then
            return G_ItemTable[Index]
        else
            local Conf = G_ItemTable[math.floor(Index / 512)]
            if Conf == nil then
                return nil
            end
            Conf = Conf[(Index % 512)]
            if Conf == nil then
                return nil
            end
            Conf = Conf[Pos]
            if Conf == nil then
                return nil
            end
            return Conf
        end
    end

    -- ItemDropRate
    G_ItemDropOptionRate = {}
    for k, v in pairs(_data["ITEM_ITEMOPTIONRATE"]) do
        G_ItemDropOptionRate[k] = {}

        for i, a in pairs(v) do
            G_ItemDropOptionRate[k][i] = {}

            for j, p in pairs(a) do
                if j > 1 then
                    for key = 1, p, 1 do
                        table.insert(G_ItemDropOptionRate[k][i], j - 2)
                    end
                end
            end
        end
    end

    -- SocketItemType
    G_ItemDropSocketRate = {}
    if Season >= 4 then
        for k, v in pairs(_data["ITEM_SOCKETITEMTYPE"][-1]) do
            G_ItemDropSocketRate[v[1]] = v
        end
    end

    -- SetItemType
    G_ItemDropAncientRate = {}
    if Season >= 0 then
        for k, v in pairs(_data["ITEM_SETITEMTYPE"][-1]) do
            G_ItemDropAncientRate[v[1]] = v
        end
    end

    -- ExcellentOptionRate
    G_ItemDropExcellentRate = {}
    for k, v in pairs(_data["ITEM_EXCELLENTOPTIONRATE"][-1]) do
        for b = v[2], v[3], 1 do
            if G_ItemDropExcellentRate[b] == nil then
                G_ItemDropExcellentRate[b] = {}
            end

            local LastID = #G_ItemDropExcellentRate[b] + 1

            for r = LastID, (LastID + v[5]), 1 do
                table.insert(G_ItemDropExcellentRate[b], v[1])
            end
        end
    end

    -- ItemOption
    G_ItemOption = {}
    for k, v in pairs(_data["ITEM_ITEMOPTION"][-1]) do
        for i = v[4], v[5] do
            if G_ItemOption[i] == nil then
                G_ItemOption[i] = {}
            end

            if v[6] ~= -1 then
                G_ItemOption[i][v[2]] = {100, v[3]}
            end
            if v[7] ~= -1 then
                G_ItemOption[i][v[2]] = {101, v[3]}
            end
            if v[8] ~= -1 then
                G_ItemOption[i][v[2]] = {102, v[3]}
            end
            if v[9] ~= -1 then
                G_ItemOption[i][v[2]] = {v[9], v[3]}
            end

            if v[6] == -1 and v[7] == -1 and v[8] == -1 and v[9] == -1 then
                G_ItemOption[i][v[2]] = {0, v[3]}
            end
        end
    end

    -- CommandManager
    G_Command = {}
    G_LoadCommand = function(aIndex)
        return G_Command[aIndex]
    end
    for k, v in pairs(_data["COMMANDMANAGER"][-1]) do
        for i, a in pairs(v) do
            G_Command[v[1]] = v
        end
    end

    -- Effect
    G_LoadEffect = {}
    for k, v in pairs(_data["EFFECT"][-1]) do
        for i, a in pairs(v) do
            G_LoadEffect[v[1]] = v
        end
    end

    -- Mastery Option
    G_MasteryOptionTable = {}
    G_MasteryOption = function(aIndex)
        return G_MasteryOptionTable[aIndex]
    end
    if Season > 6 then
        for k, v in pairs(_data["ITEM_MASTERYOPTION"]) do
            if G_MasteryOptionTable[k] == nil then
                G_MasteryOptionTable[k] = {}
            end

            for i, a in pairs(v) do
                if G_MasteryOptionTable[k][a[1]] == nil then
                    G_MasteryOptionTable[k][a[1]] = {}
                end
                G_MasteryOptionTable[k][a[1]][a[2]] = {a[3], a[4]}
            end
        end
    end

    -- MasteryItem
    G_MasteryTypeTable = {}
    G_MasteryType = function(aIndex)
        return G_MasteryTypeTable[aIndex]
    end
    if Season > 6 then
        for k, v in pairs(_data["ITEM_MASTERYITEM"][-1]) do
            G_MasteryTypeTable[v[1]] = {v[2], v[3]}
        end
    end

    -- Monster
    G_Monster = {}
    for k, v in pairs(_data["MONSTER_MONSTER"][-1]) do
        G_Monster[v[1]] = v
    end

    -- 380ItemOption
    G_RefineOptionTable = {}
    G_RefineOption = function(aIndex)
        return G_RefineOptionTable[aIndex]
    end
    if Season > 2 then
        for k, v in pairs(_data["ITEM_380ITEMOPTION"][-1]) do
            G_RefineOptionTable[v[1]] = {v[2], v[3]}
        end
    end

    -- 380ItemType
    G_RefineTypeTable = {}
    G_RefineType = function(aIndex)
        return G_RefineTypeTable[aIndex]
    end
    if Season > 2 then
        for k, v in pairs(_data["ITEM_380ITEMTYPE"][-1]) do
            G_RefineTypeTable[v[1]] = {
                string.format("%s +%d", G_RefineOption(v[2])[1], G_RefineOption(v[2])[2]),
                string.format("%s +%d", G_RefineOption(v[4])[1], G_RefineOption(v[4])[2])
            }
        end
    end

    -- Skill
    G_Skill = {}
    for k, v in pairs(_data["SKILL_SKILL"][-1]) do
        G_Skill[v[1]] = v
    end

    -- SocketItemType
    G_SocketTypeTable = {}
    G_SocketType = function(aIndex)
        return G_SocketTypeTable[aIndex]
    end
    if Season >= 4 then
        for k, v in pairs(_data["ITEM_SOCKETITEMTYPE"][-1]) do
            G_SocketTypeTable[v[1]] = v[2]
        end
    end

    -- SocketItemOption
    G_SocketOptionTable = {
        [0] = {[254] = {Name = "Free Slot", [1] = 0}},
        [1] = {[254] = {Name = "Free Slot", [1] = 0}}
    }
    G_SocketOption = function(aIndex)
        return G_SocketOptionTable[aIndex]
    end
    if Season >= 4 then
        for k, v in pairs(_data["ITEM_SOCKETITEMOPTION"][0]) do
            local Row = {}
            Row.Name = v[4]
            Row[1] = v[6]
            Row[2] = v[7]
            Row[3] = v[8]
            Row[4] = v[9]
            Row[5] = v[10]
            Row[6] = v[11]
            Row[7] = v[12]
            Row[8] = v[13]
            Row[9] = v[14]
            Row[10] = v[15]

            G_SocketOptionTable[v[2] % 2][k] = Row
        end
    end
    G_Socket = function(aIndex)
        if G_SocketTypeTable[aIndex] == nil then
            return nil
        elseif math.floor(aIndex / 512) < 6 then
            return G_SocketOptionTable[1]
        elseif math.floor(aIndex / 512) < 12 then
            return G_SocketOptionTable[0]
        else
            return nil
        end
    end
end
