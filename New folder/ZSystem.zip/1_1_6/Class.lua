_class.list = {}

for k, v in pairs(_class.ex) do
  _class.list[k - 1] = v[1]
end

G_Class = _class.list
G_ClassEx = _class.ex
