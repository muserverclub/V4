Bridge_Thread_Clock = os.clock()
Bridge_Thread_Table = {}
BridgeDelay = {}
BridgeDelay_AddDelay = function(aIndex)
	BridgeDelay[aIndex] = os.time() + 1
end

BridgeFunctionTable = {}

function BridgeFunctionAttach(BridgeName, FunctionName)
	if BridgeName == "OnReadScript" then
		if BridgeFunctionTable[1] == nil then
			BridgeFunctionTable[1] = {}
		end
		table.insert(BridgeFunctionTable[1], {Function = FunctionName})
	elseif BridgeName == "OnShutScript" then
		if BridgeFunctionTable[2] == nil then
			BridgeFunctionTable[2] = {}
		end
		table.insert(BridgeFunctionTable[2], {Function = FunctionName})
	elseif BridgeName == "OnTimerThread" then
		if BridgeFunctionTable[3] == nil then
			BridgeFunctionTable[3] = {}
		end
		table.insert(BridgeFunctionTable[3], {Function = FunctionName})
	elseif BridgeName == "OnCommandManager" then
		if BridgeFunctionTable[4] == nil then
			BridgeFunctionTable[4] = {}
		end
		table.insert(BridgeFunctionTable[4], {Function = FunctionName})
	elseif BridgeName == "OnCharacterEntry" then
		if BridgeFunctionTable[5] == nil then
			BridgeFunctionTable[5] = {}
		end
		table.insert(BridgeFunctionTable[5], {Function = FunctionName})
	elseif BridgeName == "OnCharacterClose" then
		if BridgeFunctionTable[6] == nil then
			BridgeFunctionTable[6] = {}
		end
		table.insert(BridgeFunctionTable[6], {Function = FunctionName})
	elseif BridgeName == "OnNpcTalk" then
		if BridgeFunctionTable[7] == nil then
			BridgeFunctionTable[7] = {}
		end
		table.insert(BridgeFunctionTable[7], {Function = FunctionName})
	elseif BridgeName == "OnMonsterDie" then
		if BridgeFunctionTable[8] == nil then
			BridgeFunctionTable[8] = {}
		end
		table.insert(BridgeFunctionTable[8], {Function = FunctionName})
	elseif BridgeName == "OnUserDie" then
		if BridgeFunctionTable[9] == nil then
			BridgeFunctionTable[9] = {}
		end
		table.insert(BridgeFunctionTable[9], {Function = FunctionName})
	elseif BridgeName == "OnUserRespawn" then
		if BridgeFunctionTable[10] == nil then
			BridgeFunctionTable[10] = {}
		end
		table.insert(BridgeFunctionTable[10], {Function = FunctionName})
	elseif BridgeName == "OnCheckUserTarget" then
		if BridgeFunctionTable[11] == nil then
			BridgeFunctionTable[11] = {}
		end
		table.insert(BridgeFunctionTable[11], {Function = FunctionName})
	elseif BridgeName == "OnCheckUserKiller" then
		if BridgeFunctionTable[12] == nil then
			BridgeFunctionTable[12] = {}
		end
		table.insert(BridgeFunctionTable[12], {Function = FunctionName})
	elseif BridgeName == "OnItemPick" then
		if BridgeFunctionTable[13] == nil then
			BridgeFunctionTable[13] = {}
		end
		table.insert(BridgeFunctionTable[13], {Function = FunctionName})
	elseif BridgeName == "OnItemDrop" then
		if BridgeFunctionTable[14] == nil then
			BridgeFunctionTable[14] = {}
		end
		table.insert(BridgeFunctionTable[14], {Function = FunctionName})
	elseif BridgeName == "OnPacketRecv" then
		if BridgeFunctionTable[15] == nil then
			BridgeFunctionTable[15] = {}
		end
		table.insert(BridgeFunctionTable[15], {Function = FunctionName})
	elseif BridgeName == "OnSQLAsyncResult" then
		if BridgeFunctionTable[16] == nil then
			BridgeFunctionTable[16] = {}
		end
		table.insert(BridgeFunctionTable[16], {Function = FunctionName})
	elseif BridgeName == "OnLevelUp" then
		if BridgeFunctionTable[101] == nil then
			BridgeFunctionTable[101] = {}
		end
		table.insert(BridgeFunctionTable[101], {Function = FunctionName})
	elseif BridgeName == "OnResetUp" then
		if BridgeFunctionTable[102] == nil then
			BridgeFunctionTable[102] = {}
		end
		table.insert(BridgeFunctionTable[102], {Function = FunctionName})
	elseif BridgeName == "OnPartyEnter" then
		if BridgeFunctionTable[103] == nil then
			BridgeFunctionTable[103] = {}
		end
		table.insert(BridgeFunctionTable[103], {Function = FunctionName})
	elseif BridgeName == "OnPartyClose" then
		if BridgeFunctionTable[104] == nil then
			BridgeFunctionTable[104] = {}
		end
		table.insert(BridgeFunctionTable[104], {Function = FunctionName})
	elseif BridgeName == "OnGuildEnter" then
		if BridgeFunctionTable[105] == nil then
			BridgeFunctionTable[105] = {}
		end
		table.insert(BridgeFunctionTable[105], {Function = FunctionName})
	elseif BridgeName == "OnGuildClose" then
		if BridgeFunctionTable[106] == nil then
			BridgeFunctionTable[106] = {}
		end
		table.insert(BridgeFunctionTable[106], {Function = FunctionName})
	elseif BridgeName == "OnMasterResetUp" then
		if BridgeFunctionTable[107] == nil then
			BridgeFunctionTable[107] = {}
		end
		table.insert(BridgeFunctionTable[107], {Function = FunctionName})
	elseif BridgeName == "OnMasterLevelUp" then
		if BridgeFunctionTable[108] == nil then
			BridgeFunctionTable[108] = {}
		end
		table.insert(BridgeFunctionTable[108], {Function = FunctionName})
	elseif BridgeName == "OnTimeUp" then
		if BridgeFunctionTable[109] == nil then
			BridgeFunctionTable[109] = {}
		end
		table.insert(BridgeFunctionTable[109], {Function = FunctionName})
	elseif BridgeName == "OnMapChange" then
		if BridgeFunctionTable[110] == nil then
			BridgeFunctionTable[110] = {}
		end
		table.insert(BridgeFunctionTable[110], {Function = FunctionName})
	elseif BridgeName == "OnReloadScript" then
		if BridgeFunctionTable[111] == nil then
			BridgeFunctionTable[111] = {}
		end
		table.insert(BridgeFunctionTable[111], {Function = FunctionName})
	elseif BridgeName == "OnLoadScript" then
		if BridgeFunctionTable[113] == nil then
			BridgeFunctionTable[113] = {}
		end
		table.insert(BridgeFunctionTable[113], {Function = FunctionName})
	elseif BridgeName == "OnChangeUp" then
		if BridgeFunctionTable[114] == nil then
			BridgeFunctionTable[114] = {}
		end
		table.insert(BridgeFunctionTable[114], {Function = FunctionName})
	elseif BridgeName == "OnOfflineFlagEnter" then
		if BridgeFunctionTable[115] == nil then
			BridgeFunctionTable[115] = {}
		end
		table.insert(BridgeFunctionTable[115], {Function = FunctionName})
	elseif BridgeName == "OnOfflineFlagClose" then
		if BridgeFunctionTable[116] == nil then
			BridgeFunctionTable[116] = {}
		end
		table.insert(BridgeFunctionTable[116], {Function = FunctionName})
	elseif BridgeName == "OnChangeInterface" then
		if BridgeFunctionTable[117] == nil then
			BridgeFunctionTable[117] = {}
		end
		table.insert(BridgeFunctionTable[117], {Function = FunctionName})
	elseif BridgeName == "UserOnlineThread" then
		if BridgeFunctionTable[118] == nil then
			BridgeFunctionTable[118] = {}
		end
		table.insert(BridgeFunctionTable[118], {Function = FunctionName})
	elseif BridgeName == "OnUserItemMove" then
		if BridgeFunctionTable[200] == nil then
			BridgeFunctionTable[200] = {}
		end
		table.insert(BridgeFunctionTable[200], {Function = FunctionName})
	elseif BridgeName == "OnCommandDone" then
		if BridgeFunctionTable[201] == nil then
			BridgeFunctionTable[201] = {}
		end
		table.insert(BridgeFunctionTable[201], {Function = FunctionName})
	end
end

function BridgeFunctionAttach2(BridgeName, FunctionName)
	BridgeFunctionAttach(BridgeName, FunctionName)
end

function setClockTable(fn)
	local gclock = os.clock() - Bridge_Thread_Clock
	local fclock = 0

	if #Bridge_Thread_Table > 0 then
		fclock = gclock - Bridge_Thread_Table[#Bridge_Thread_Table].gclock
	end

	table.insert(
		Bridge_Thread_Table,
		{
			fname = fn,
			gclock = gclock,
			fclock = fclock
		}
	)
end

function traceback(fn, params)
	local func = {}
	for k, v in pairs(fn:split("%.")) do
		func = func[v] or _G[v]
	end

	if func ~= nil then
		if MuServerClub_Username_Id == 55 then
			local status, ret, err = xpcall(func, debug.traceback, unpack(params))

			setClockTable(fn)

			if status == false then
				for k, v in pairs(ret:split("\n")) do
					LogPrint(v)
				end
			else
				return ret
			end
		else
			local ret = func(unpack(params))

			setClockTable(fn)

			return ret
		end
	else
		LogPrint(("Invalid bridge: %s"):format(fn))
	end
end

function BridgeFunction_OnReadScript()
	if BridgeFunctionTable[1] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[1])) do
			traceback(v.Function, {})
		end
	end
end

function BridgeFunction_OnShutScript()
	if BridgeFunctionTable[2] ~= nil then
		for k, v in pairs(SetBridgeOrderReverse(BridgeFunctionTable[2])) do
			traceback(v.Function, {})
		end
	end
end

function BridgeFunction_OnTimerThread()
	if BridgeFunctionTable[3] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[3])) do
			traceback(v.Function, {})
		end
	end
	if LagDetection == true then
		local Clock = (os.clock() - Bridge_Thread_Clock)
		if Clock > 1.2 then
			local Timer = os.date("%c")
			_cache.setDate(Timer, nil, Clock, "LagDetection")

			if Clock > 1.5 then
				LogColor(1, "[WARNING] GameServer CRITICAL Lag Detected!!")
				_cache.setDate(Timer, nil, "CRITICAL | OVER 1.5", "LagDetection")
			elseif Clock > 1.4 then
				LogColor(1, "[WARNING] GameServer HIGH Lag Detected!!")
				_cache.setDate(Timer, nil, "HIGH | OVER 1.4", "LagDetection")
			elseif Clock > 1.3 then
				LogColor(1, "[WARNING] GameServer MEDIUM Lag Detected!!")
				_cache.setDate(Timer, nil, "MEDIUM | OVER 1.3", "LagDetection")
			else
				LogColor(1, "[WARNING] GameServer LOW Lag Detected!!")
				_cache.setDate(Timer, nil, "LOW | OVER 1.2", "LagDetection")
			end

			for k, v in pairs(Bridge_Thread_Table) do
				if k == 1 or v.fclock > 0.09 then
					_cache.setDate(Timer, nil, v, "LagDetection")
				end
			end
		end

		Bridge_Thread_Clock = os.clock()
		Bridge_Thread_Table = {}
	end
end

function BridgeFunction_OnCommandManager(aIndex, code, arg)
	if BridgeDelay[aIndex] == nil or BridgeDelay[aIndex] < os.time() then
		if BridgeFunctionTable[4] ~= nil then
			for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[4])) do
				local ret = traceback(v.Function, {aIndex, code, arg})
				if ret ~= nil and ret ~= 0 then
					BridgeDelay_AddDelay(aIndex)
					return 1
				end
			end
		end
	else
		return 1
	end
	return 0
end

function BridgeFunction_OnCharacterEntry(aIndex)
	if BridgeFunctionTable[5] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[5])) do
			traceback(v.Function, {aIndex})
		end
	end
end

function BridgeFunction_OnCharacterClose(aIndex)
	if BridgeFunctionTable[6] ~= nil then
		for k, v in pairs(SetBridgeOrderReverse(BridgeFunctionTable[6])) do
			traceback(v.Function, {aIndex})
		end
	end
end

function BridgeFunction_OnNpcTalk(aIndex, bIndex)
	if BridgeDelay[bIndex] == nil or BridgeDelay[bIndex] < os.time() then
		if BridgeFunctionTable[7] ~= nil then
			for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[7])) do
				local ret = traceback(v.Function, {aIndex, bIndex})
				if ret ~= nil and ret ~= 0 then
					BridgeDelay_AddDelay(bIndex)
					return 1
				end
			end
		end
	else
		return 1
	end
	return 0
end

function BridgeFunction_OnMonsterDie(aIndex, bIndex)
	if BridgeFunctionTable[8] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[8])) do
			traceback(v.Function, {aIndex, bIndex})
		end
	end
end

function BridgeFunction_OnUserDie(aIndex, bIndex)
	if BridgeFunctionTable[9] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[9])) do
			traceback(v.Function, {aIndex, bIndex})
		end
	end
end

function BridgeFunction_OnUserRespawn(aIndex, KillerType)
	if BridgeFunctionTable[10] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[10])) do
			traceback(v.Function, {aIndex, KillerType})
		end
	end
end

function BridgeFunction_OnCheckUserTarget(aIndex, bIndex)
	if BridgeFunctionTable[11] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[11])) do
			local ret = traceback(v.Function, {aIndex, bIndex})
			if ret ~= nil and ret == 0 then
				return 0
			end
		end
	end
	return 1
end

function BridgeFunction_OnCheckUserKiller(aIndex, bIndex)
	if BridgeFunctionTable[12] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[12])) do
			local ret = traceback(v.Function, {aIndex, bIndex})
			if ret ~= nil and ret == 0 then
				return 0
			end
		end
	end
	return 1
end

function BridgeFunction_OnItemPick(aIndex, index, ItemTable)
	if BridgeFunctionTable[13] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[13])) do
			local ret = traceback(v.Function, {aIndex, index, ItemTable})
			if ret ~= nil and ret == 0 then
				return 0
			end
		end
	end
	return 1
end

function BridgeFunction_OnItemDrop(aIndex, index, x, y, ItemTable)
	if BridgeFunctionTable[14] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[14])) do
			local ret = traceback(v.Function, {aIndex, index, x, y, ItemTable})
			if ret ~= nil and ret == 0 then
				return 0
			end
		end
	end
	return 1
end

function BridgeFunction_OnPacketRecv(aIndex, buff, size)
	if BridgeFunctionTable[15] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[15])) do
			traceback(v.Function, {aIndex, buff, size})
		end
	end
end

function BridgeFunction_OnSQLAsyncResult(label, param, result)
	if BridgeFunctionTable[16] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[16])) do
			local ret = traceback(v.Function, {label, param, result})
			if ret ~= nil then
				if ret == 1 then
					return 0
				end
				if ret == 2 then
					return 1
				end
			end
		end
	end
	return 0
end

function BridgeFunction_OnLevelUp(aIndex)
	if BridgeFunctionTable[101] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[101])) do
			traceback(v.Function, {aIndex})
		end
	end
end

function BridgeFunction_OnMasterLevelUp(aIndex)
	if BridgeFunctionTable[108] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[108])) do
			traceback(v.Function, {aIndex})
		end
	end
end

function BridgeFunction_OnTimeUp(aIndex)
	if BridgeFunctionTable[109] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[109])) do
			traceback(v.Function, {aIndex})
		end
	end
end

function BridgeFunction_OnMapChange(aIndex, OldMap, NewMap)
	if BridgeFunctionTable[110] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[110])) do
			traceback(v.Function, {aIndex, OldMap, NewMap})
		end
	end
end

function BridgeFunction_OnResetUp(aIndex)
	if BridgeFunctionTable[102] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[102])) do
			traceback(v.Function, {aIndex})
		end
	end
end

function BridgeFunction_OnMasterResetUp(aIndex)
	if BridgeFunctionTable[107] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[107])) do
			traceback(v.Function, {aIndex})
		end
	end
end

function BridgeFunction_OnPartyEnter(aIndex, bIndex, Members)
	if BridgeFunctionTable[103] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[103])) do
			traceback(v.Function, {aIndex, bIndex, Members})
		end
	end
end

function BridgeFunction_OnPartyClose(aIndex, Members)
	if BridgeFunctionTable[104] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[104])) do
			traceback(v.Function, {aIndex, Members})
		end
	end
end

function BridgeFunction_OnGuildEnter(aIndex, GuildName)
	if BridgeFunctionTable[105] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[105])) do
			traceback(v.Function, {aIndex, GuildName})
		end
	end
end

function BridgeFunction_OnGuildClose(aIndex, GuildName)
	if BridgeFunctionTable[106] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[106])) do
			traceback(v.Function, {aIndex, GuildName})
		end
	end
end

function BridgeFunction_OnReloadScript(arg)
	if BridgeFunctionTable[111] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[111])) do
			traceback(v.Function, {arg})
		end
	end
end

function BridgeFunction_OnLoadScript(arg)
	if BridgeFunctionTable[113] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[113])) do
			traceback(v.Function, {arg})
		end
	end
end

function BridgeFunction_OnChangeUp(arg, Class)
	if BridgeFunctionTable[114] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[114])) do
			traceback(v.Function, {arg, Class})
		end
	end
end

function BridgeFunction_OnOfflineFlagEnter(arg)
	if BridgeFunctionTable[115] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[115])) do
			traceback(v.Function, {arg})
		end
	end
end

function BridgeFunction_OnOfflineFlagClose(arg)
	if BridgeFunctionTable[116] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[116])) do
			traceback(v.Function, {arg})
		end
	end
end

function BridgeFunction_OnChangeInterface(arg, old, new)
	if BridgeFunctionTable[117] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[117])) do
			traceback(v.Function, {arg, old, new})
		end
	end
end

function BridgeFunction_UserOnlineThread(arg)
	if BridgeFunctionTable[118] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[118])) do
			traceback(v.Function, {arg})
		end
	end
end

function BridgeFunction_OnUserItemMove(aIndex, aFlag, aSlot, bFlag, bSlot)
	if BridgeFunctionTable[200] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[200])) do
			traceback(v.Function, {aIndex, aFlag, aSlot, bFlag, bSlot})
		end
	end
end

function BridgeFunction_OnCommandDone(aIndex, code)
	if BridgeFunctionTable[201] ~= nil then
		for k, v in pairs(SetBridgeOrder(BridgeFunctionTable[201])) do
			traceback(v.Function, {aIndex, code})
		end
	end
end

function ScriptLoader_AddOnReadScript(name)
	BridgeFunctionAttach("OnReadScript", name)
end

function ScriptLoader_AddOnShutScript(name)
	BridgeFunctionAttach("OnShutScript", name)
end

function ScriptLoader_AddOnTimerThread(name)
	BridgeFunctionAttach("OnTimerThread", name)
end

function ScriptLoader_AddOnCommandManager(name)
	BridgeFunctionAttach("OnCommandManager", name)
end

function ScriptLoader_AddOnCharacterEntry(name)
	BridgeFunctionAttach("OnCharacterEntry", name)
end

function ScriptLoader_AddOnCharacterClose(name)
	BridgeFunctionAttach("OnCharacterClose", name)
end

function ScriptLoader_AddOnNpcTalk(name)
	BridgeFunctionAttach("OnNpcTalk", name)
end

function ScriptLoader_AddOnMonsterDie(name)
	BridgeFunctionAttach("OnMonsterDie", name)
end

function ScriptLoader_AddOnUserDie(name)
	BridgeFunctionAttach("OnUserDie", name)
end

function ScriptLoader_AddOnUserRespawn(name)
	BridgeFunctionAttach("OnUserRespawn", name)
end

function ScriptLoader_AddOnCheckUserTarget(name)
	BridgeFunctionAttach("OnCheckUserTarget", name)
end

function ScriptLoader_AddOnCheckUserKiller(name)
	BridgeFunctionAttach("OnCheckUserKiller", name)
end

function ScriptLoader_AddOnCheckUserKiller(name)
	BridgeFunctionAttach("OnCheckUserKiller", name)
end

function ScriptLoader_AddOnPacketRecv(name)
	BridgeFunctionAttach("OnPacketRecv", name)
end

function ScriptLoader_AddOnSQLAsyncResult(name)
	BridgeFunctionAttach("OnSQLAsyncResult", name)
end

function ScriptLoader_AddOnLevelUp(name)
	BridgeFunctionAttach("OnLevelUp", name)
end

function ScriptLoader_AddOnMasterLevelUp(name)
	BridgeFunctionAttach("OnMasterLevelUp", name)
end

function ScriptLoader_AddOnTimeUp(name)
	BridgeFunctionAttach("OnTimeUp", name)
end

function ScriptLoader_AddOnResetUp(name)
	BridgeFunctionAttach("OnResetUp", name)
end

function ScriptLoader_AddOnMapChange(name)
	BridgeFunctionAttach("OnMapChange", name)
end

function ScriptLoader_AddOnMasterResetUp(name)
	BridgeFunctionAttach("OnMasterResetUp", name)
end

function ScriptLoader_AddOnPartyEnter(name)
	BridgeFunctionAttach("OnPartyEnter", name)
end

function ScriptLoader_AddOnPartyClose(name)
	BridgeFunctionAttach("OnPartyClose", name)
end

function ScriptLoader_AddOnGuildEnter(name)
	BridgeFunctionAttach("OnGuildEnter", name)
end

function ScriptLoader_AddOnGuildClose(name)
	BridgeFunctionAttach("OnGuildClose", name)
end

function ScriptLoader_AddOnReloadScript(name)
	BridgeFunctionAttach("OnReloadScript", name)
end

function ScriptLoader_AddOnLoadScript(name)
	BridgeFunctionAttach("OnLoadScript", name)
end

function ScriptLoader_AddOnChangeUp(name)
	BridgeFunctionAttach("OnChangeUp", name)
end

function ScriptLoader_AddOfflineFlagEnter(name)
	BridgeFunctionAttach("OfflineFlagEnter", name)
end

function ScriptLoader_AddOnChangeInterface(name)
	BridgeFunctionAttach("OnChangeInterface", name)
end

function ScriptLoader_AddUserOnlineThread(name)
	BridgeFunctionAttach("UserOnlineThread", name)
end

BridgeFunctionAttach("OnCharacterEntry", "Bridge_OnCharacterEntry")
BridgeFunctionAttach("OnCharacterClose", "Bridge_OnCharacterClose")
BridgeFunctionAttach("OnReadScript", "Bridge_OnReadScript")
BridgeFunctionAttach("OnShutScript", "Bridge_OnShutScript")
BridgeFunctionAttach("OnMonsterDie", "Bridge_OnMonsterDie")
BridgeFunctionAttach("OnTimerThread", "Bridge_OnTimerThread")

CharacterBridge = {}

PartyBridge = {}

GetObjectInfo = function(aIndex, Config)
	if CharacterBridge[aIndex] == nil then
		return nil
	end
	if Config == nil then
		return CharacterBridge[aIndex]
	end
	if CharacterBridge[aIndex][Config] == nil then
		return nil
	end
	return CharacterBridge[aIndex][Config]
end

Bridge_OnCharacterEntry = function(aIndex)
	local Account = GetObjectAccount(aIndex)
	CharacterBridge[aIndex] = {}
	CharacterBridge[aIndex].LevelUp = {GetObjectLevel(aIndex), (GetObjectLevel(aIndex) - 1)}
	if Season > 2 then
		CharacterBridge[aIndex].MasterLevelUp = {
			GetObjectMasterLevel(aIndex),
			((GetObjectMasterLevel(aIndex) - 1) < 1 and 0 or GetObjectMasterLevel(aIndex))
		}
	end
	CharacterBridge[aIndex].ResetUp = {
		GetObjectReset(aIndex),
		(GetObjectReset(aIndex) - 1 < 0 and 0 or GetObjectReset(aIndex))
	}
	CharacterBridge[aIndex].MasterResetUp = {
		GetObjectMasterReset(aIndex),
		(GetObjectMasterReset(aIndex) - 1 < 0 and 0 or GetObjectMasterReset(aIndex))
	}
	CharacterBridge[aIndex].PartyNumber = GetObjectPartyNumber(aIndex)
	CharacterBridge[aIndex].GuildName = GetObjectGuildName(aIndex)
	CharacterBridge[aIndex].TimeUp = 0
	CharacterBridge[aIndex].MapChange = {0, GetObjectMap(aIndex)}

	if CharacterBridge[aIndex].PartyNumber ~= -1 then
		if PartyBridge[CharacterBridge[aIndex].PartyNumber] ~= nil then
			PartyBridge[CharacterBridge[aIndex].PartyNumber][aIndex] = 1
		else
			PartyBridge[CharacterBridge[aIndex].PartyNumber] = {}
			PartyBridge[CharacterBridge[aIndex].PartyNumber][aIndex] = 1
		end
	end

	CharacterBridge[aIndex].ChangeUp = _user.classEx(aIndex)
	CharacterBridge[aIndex].OfflineFlag = GetObjectOfflineFlag(aIndex)

	CharacterBridge[aIndex].Interface = GetObjectInterface(aIndex)

	local success, memb___id, hwid, auth2fa =
		SQLQuery("SELECT * FROM MEMB_INFO WHERE memb___id='%s'", {Account}, {"memb___id", "hwid", "auth2fa"})

	CharacterBridge[aIndex].MEMB_INFO = {
		memb___id = memb___id,
		hwid = hwid:gsub("[^%w]", ""),
		auth2fa = tonumber(auth2fa) or 0
	}
end

Bridge_OnCharacterClose = function(aIndex)
	if PartyBridge[GetObjectPartyNumber(aIndex)] ~= nil then
		PartyBridge[GetObjectPartyNumber(aIndex)][aIndex] = nil
	end
	CharacterBridge[aIndex] = nil
end

Bridge_OnReadScript = function()
	for aIndex = GetMinUserIndex(), GetMaxUserIndex() do
		if GetObjectConnected(aIndex) == 3 and GetObjectName(aIndex) ~= "" then
			Bridge_OnCharacterEntry(aIndex)
		end
	end
end

Bridge_OnShutScript = function()
	for aIndex = GetMinUserIndex(), GetMaxUserIndex() do
		if GetObjectConnected(aIndex) == 3 and GetObjectName(aIndex) ~= "" then
			Bridge_OnCharacterClose(aIndex, 1)
		end
	end
end

Bridge_OnMonsterDie = function(aIndex, bIndex)
	--SetObjectLevelUp(bIndex)
	--SetObjectMasterLevelUp(bIndex)
end

Bridge_OnTimerThread = function()
	for aIndex, data in pairs(CharacterBridge) do
		if aIndex ~= nil and GetObjectConnected(aIndex) == 3 then
			SetObjectLevelUp(aIndex)
			SetObjectMasterLevelUp(aIndex)
			SetObjectResetUp(aIndex)
			SetObjectMasterResetUp(aIndex)
			SetObjectPartyEnter(aIndex)
			SetObjectGuildEnter(aIndex)
			SetObjectTimeUp(aIndex)
			SetObjectMapChange(aIndex)
			SetObjectChangeUp(aIndex)
			SetObjectOfflineFlag(aIndex)
			SetObjectInterface(aIndex)
			BridgeFunction_UserOnlineThread(aIndex)
		end
	end

	_time.count = _time.count + 1

	if os.date("%H:%M:%S") == "00:00:00" then
		os.execute("mkdir " .. _cache.dirDate())
	end

	for k, v in pairs(_monster.deleteList) do
		if v <= os.time() then
			MonsterDelete(k)
			_monster.deleteList[k] = nil
		end
	end
end

SetObjectLevelUp = function(aIndex)
	if CharacterBridge[aIndex].LevelUp[1] ~= nil then
		if (CharacterBridge[aIndex].LevelUp[1] ~= GetObjectLevel(aIndex)) then
			CharacterBridge[aIndex].LevelUp[2] = CharacterBridge[aIndex].LevelUp[1]
			CharacterBridge[aIndex].LevelUp[1] = GetObjectLevel(aIndex)
			BridgeFunction_OnLevelUp(aIndex)
		end
	end
end

SetObjectMasterLevelUp = function(aIndex)
	if Season > 2 then
		if (CharacterBridge[aIndex].MasterLevelUp[1] ~= GetObjectMasterLevel(aIndex)) then
			CharacterBridge[aIndex].MasterLevelUp[2] = CharacterBridge[aIndex].MasterLevelUp[1]
			CharacterBridge[aIndex].MasterLevelUp[1] = GetObjectMasterLevel(aIndex)
			BridgeFunction_OnMasterLevelUp(aIndex)
		end
	end
end

GetObjectLevelOld = function(aIndex)
	return CharacterBridge[aIndex].LevelUp[2]
end

GetObjectMasterLevelOld = function(aIndex)
	return CharacterBridge[aIndex].MasterLevelUp[2]
end

SetObjectTimeUp = function(aIndex)
	if GetObjectOfflineFlag(aIndex) == 0 then
		CharacterBridge[aIndex].TimeUp = CharacterBridge[aIndex].TimeUp + 1

		if CharacterBridge[aIndex].TimeUp % 60 == 0 then
			BridgeFunction_OnTimeUp(aIndex)
		end
	end
end

GetObjectTime = function(aIndex)
	return CharacterBridge[aIndex].TimeUp
end

SetObjectMapChange = function(aIndex)
	local NewMap = GetObjectMap(aIndex)
	local OldMap = CharacterBridge[aIndex].MapChange[2]

	if OldMap ~= NewMap then
		CharacterBridge[aIndex].MapChange = {OldMap, NewMap}

		BridgeFunction_OnMapChange(aIndex, OldMap, NewMap)
	end
end

GetObjectMapChange = function(aIndex)
	return CharacterBridge[aIndex].MapChange[1]
end

SetObjectMasterResetUp = function(aIndex)
	if CharacterBridge[aIndex].MasterResetUp[1] ~= GetObjectMasterReset(aIndex) then
		CharacterBridge[aIndex].MasterResetUp[2] = CharacterBridge[aIndex].MasterResetUp[1]
		CharacterBridge[aIndex].MasterResetUp[1] = GetObjectMasterReset(aIndex)
		BridgeFunction_OnMasterResetUp(aIndex)
	end
end

GetObjectMasterResetOld = function(aIndex)
	return CharacterBridge[aIndex].MasterResetUp[2]
end

SetObjectResetUp = function(aIndex)
	if CharacterBridge[aIndex].ResetUp[1] ~= GetObjectReset(aIndex) then
		CharacterBridge[aIndex].ResetUp[2] = CharacterBridge[aIndex].ResetUp[1]
		CharacterBridge[aIndex].ResetUp[1] = GetObjectReset(aIndex)
		BridgeFunction_OnResetUp(aIndex)
	end
end

GetObjectResetOld = function(aIndex)
	return CharacterBridge[aIndex].ResetUp[2]
end

SetObjectPartyEnter = function(aIndex)
	local PartyIndex = GetObjectPartyNumber(aIndex)
	if CharacterBridge[aIndex].PartyNumber ~= PartyIndex then
		if PartyIndex ~= -1 then
			PartyBridge[PartyIndex] = {}
			local PartyCount = PartyGetMemberCount(PartyIndex)
			for i = 0, 5 do
				local IndexParty = PartyGetMemberIndex(PartyIndex, i)
				if IndexParty ~= -1 then
					PartyBridge[PartyIndex][IndexParty] = GetObjectName(IndexParty)
				end
			end
			BridgeFunction_OnPartyEnter(aIndex, GetObjectPartyNumber(aIndex), PartyBridge[PartyIndex])
		else
			for k, v in pairs(PartyBridge[CharacterBridge[aIndex].PartyNumber]) do
				if v == GetObjectName(aIndex) then
					PartyBridge[CharacterBridge[aIndex].PartyNumber][k] = nil
				end
			end
			BridgeFunction_OnPartyClose(aIndex, PartyBridge[CharacterBridge[aIndex].PartyNumber])
		end
		CharacterBridge[aIndex].PartyNumber = PartyIndex
	end
end

SetObjectGuildEnter = function(aIndex)
	local GName = GetObjectGuildName(aIndex)
	if CharacterBridge[aIndex].GuildName ~= GName then
		if GetObjectGuildNumber(aIndex) ~= 0 then
			BridgeFunction_OnGuildEnter(aIndex, GName)
		else
			BridgeFunction_OnGuildClose(aIndex, CharacterBridge[aIndex].GuildName)
		end
		CharacterBridge[aIndex].GuildName = GName
	end
end

SetObjectChangeUp = function(aIndex)
	local ChangeUp = _user.classEx(aIndex)
	if CharacterBridge[aIndex].ChangeUp ~= ChangeUp then
		CharacterBridge[aIndex].ChangeUp = ChangeUp
		BridgeFunction_OnChangeUp(aIndex, ChangeUp)
	end
end

SetObjectOfflineFlag = function(aIndex)
	local OfflineFlag = GetObjectOfflineFlag(aIndex)
	if CharacterBridge[aIndex].OfflineFlag ~= OfflineFlag then
		if OfflineFlag == 1 then
			BridgeFunction_OnOfflineFlagEnter(aIndex)
		else
			BridgeFunction_OnOfflineFlagClose(aIndex)
		end
		CharacterBridge[aIndex].OfflineFlag = OfflineFlag
	end
end

SetObjectInterface = function(aIndex)
	local Interface = GetObjectInterface(aIndex)
	if CharacterBridge[aIndex].Interface ~= Interface then
		BridgeFunction_OnChangeInterface(aIndex, CharacterBridge[aIndex].Interface, Interface)
		CharacterBridge[aIndex].Interface = Interface
	end
end
