PermissionRemove2 = PermissionRemove
PermissionRemove = function(aIndex,Value)
    if type(Value) == "table" then
        for k,v in pairs(Value) do
            PermissionRemove2(aIndex,v)
        end
    else
        PermissionRemove2(aIndex,Value)
    end
end

PermissionInsert2 = PermissionInsert
PermissionInsert = function(aIndex,Value)
    if type(Value) == "table" then
        for k,v in pairs(Value) do
            PermissionInsert2(aIndex,v)
        end
    else
        PermissionInsert2(aIndex,Value)
    end
end