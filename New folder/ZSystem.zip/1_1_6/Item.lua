_item.check = function(aIndex, Config, Slots)
    for i = 12, InventoryGetFullSize() do
        if table.find(i, Slots) == -1 then
            local ItemTable = InventoryGetItemTable(aIndex, i)

            if ItemTable ~= nil then
                if Config.Index == nil or Config.Index == ItemTable.Index then
                    if
                        Config.MinLevel == nil or Config.MaxLevel == nil or
                            (ItemTable.Level >= Config.MinLevel and ItemTable.Level <= Config.MaxLevel)
                     then
                        if Config.Skill == nil or Config.Skill == ItemTable.Option2 then
                            if Config.Luck == nil or Config.Luck == ItemTable.Option1 then
                                if
                                    Config.MinOption == nil or Config.MaxOption == nil or
                                        (ItemTable.Option3 >= Config.MinOption and ItemTable.Option3 <= Config.MaxOption)
                                 then
                                    if Config.ExcType == nil or Config.ExcType == ItemTable.NewOption then
                                        local CountExc = 0
                                        if ItemTable.NewOption >= 32 then
                                            CountExc = CountExc + 1
                                            ItemTable.NewOption = ItemTable.NewOption - 32
                                        end
                                        if ItemTable.NewOption >= 16 then
                                            CountExc = CountExc + 1
                                            ItemTable.NewOption = ItemTable.NewOption - 16
                                        end
                                        if ItemTable.NewOption >= 8 then
                                            CountExc = CountExc + 1
                                            ItemTable.NewOption = ItemTable.NewOption - 8
                                        end
                                        if ItemTable.NewOption >= 4 then
                                            CountExc = CountExc + 1
                                            ItemTable.NewOption = ItemTable.NewOption - 4
                                        end
                                        if ItemTable.NewOption >= 2 then
                                            CountExc = CountExc + 1
                                            ItemTable.NewOption = ItemTable.NewOption - 2
                                        end
                                        if ItemTable.NewOption >= 1 then
                                            CountExc = CountExc + 1
                                            ItemTable.NewOption = ItemTable.NewOption - 1
                                        end

                                        if
                                            Config.MinExc == nil or Config.MaxExc == nil or
                                                (CountExc >= Config.MinExc and CountExc <= Config.MaxExc)
                                         then
                                            if
                                                Config.SetOption == nil or
                                                    (Config.SetOption == 0 and ItemTable.SetOption == 0) or
                                                    (Config.SetOption > 0 and ItemTable.SetOption > 0)
                                             then
                                                if
                                                    Config.JoHOption == nil or
                                                        (Config.JoHOption == 0 and ItemTable.JoHOption == 0) or
                                                        (Config.JoHOption > 0 and ItemTable.JoHOption > 0)
                                                 then
                                                    if
                                                        Config.Option380 == nil or
                                                            (Config.Option380 == 0 and ItemTable["380Option"] == 0) or
                                                            (Config.Option380 > 0 and ItemTable["380Option"] > 0)
                                                     then
                                                        return i
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return 0
end

_item.index = function(aValue, bValue)
    -- aValue = item id to be parsed or section
    -- bValue = section id
    -- return calculated item index, section, id
    if bValue == nil then
        local sfind = string.find(aValue, ",")

        if sfind ~= nil then
            local section = tonumber(string.sub(aValue, 1, (sfind - 1)))
            local index = tonumber(string.sub(aValue, (sfind + 1), string.len(aValue)))
            if tonumber(section) ~= nil and tonumber(index) ~= nil then
                aValue = section * 512 + index
            end
        end

        if tonumber(aValue) == nil then
            return aValue
        end

        return aValue, math.floor(aValue / 512), (aValue % 512)
    end

    return (aValue * 512) + bValue, aValue, bValue
end

_item.exists = function(aValue, bValue)
    -- aValue = item id to be parsed or section
    -- bValue = section id
    -- return item data
    local index, section, id = _item.index(aValue, bValue)
    if _data["ITEM_ITEM"][section] == nil or _data["ITEM_ITEM"][section][id] == nil then
        return {}, section, id
    end

    return _data["ITEM_ITEM"][section][id], section, id
end

_item.name = function(aValue, bValue)
    -- aValue = item id to be parsed or section
    -- bValue = section id
    -- return item name
    local item = _item.exists(aValue, bValue)
    return item[9] or ""
end

_item.skill = function(aValue, bValue)
    -- aValue = item id to be parsed or section
    -- bValue = section id
    -- return item skill
    local item = _item.exists(aValue, bValue)
    return item[3] or 0
end

_item.luck = function(aValue, bValue)
    -- aValue = item id to be parsed or section
    -- bValue = section id
    -- return item luck
    local item, section, id = _item.exists(aValue, bValue)
    if (section == 13 and id == 30) or table.find(section, {13, 14, 15}) == -1 then
        return item[7] or 0
    end
    return 0
end

_item.excellent = function(aValue, bValue)
    -- aValue = item id to be parsed or section
    -- bValue = section id
    -- return item luck
    local item = _item.exists(aValue, bValue)
    return item[7] or 0
end

-- Support to old functions
G_ItemCheck = _item.check
