ReplaceOldDir = function(...)
    local arg = table.pack(...)
    for k, v in pairs(arg) do
        v = ("%s"):format(v):gsub("\\", "/")
        local path = _path.script:gsub("\\", "/")
        if v:find(path) ~= 1 and v:find("Script/") ~= nil then
            arg[k] = table.concat({path, (v:match("Script/(.+)"))}, "/")
        end
    end
    return unpack(arg)
end

ConfigReadNumber2 = ConfigReadNumber
ConfigReadNumber = function(...)
    return ConfigReadNumber2(ReplaceOldDir(...))
end

ConfigReadString2 = ConfigReadString
ConfigReadString = function(...)
    return ConfigReadString2(ReplaceOldDir(...))
end

ConfigSaveString2 = ConfigSaveString
ConfigSaveString = function(...)
    return ConfigSaveString2(ReplaceOldDir(...))
end

io.popen2 = io.popen
io.popen = function(...)
    return io.popen2(ReplaceOldDir(...))
end

io.open2 = io.open
io.open = function(...)
    return io.open2(ReplaceOldDir(...))
end
