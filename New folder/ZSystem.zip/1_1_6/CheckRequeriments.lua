G_CommandController = {}
BridgeFunctionAttach("OnCommandManager", "G_CommandController_OnCommandManager")
G_CommandController_OnCommandManager = function(aIndex, code, arg)
    local Config = G_CommandController[code]

    if Config ~= nil then
        G_CheckRequeriments(aIndex, Config, 1, {code, arg}, true)

        return 1
    end

    return 0
end

G_NpcController = {}

BridgeFunctionAttach("OnNpcTalk", "G_NpcController_OnNpcTalk")
G_NpcController_OnNpcTalk = function(aIndex, bIndex)
    local Config = G_NpcController[aIndex]

    if Config ~= nil then
        G_CheckRequeriments(bIndex, Config, 2, aIndex, true)

        return 1
    end

    return 0
end

G_CheckRequeriments = function(aIndex, Config, Type, Data, showMessage)
    if Config.displayErrors ~= nil then
        showMessage = Config.displayErrors
    end

    if aIndex == nil then
        return 1
    end

    local interface = false

    local AccountLevel = GetObjectAccountLevel(aIndex) + 1
    local Name = GetObjectName(aIndex)

    if Config.Authority ~= nil and table.find(Name, Config.Authority) == -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_Authority)
        end
        return 0
    end

    if Config.AuthorityAccount ~= nil and table.find(GetObjectAccount(aIndex), Config.AuthorityAccount) == -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_Authority)
        end
        return 0
    end

    if Config.AllowAccountLevel ~= nil and table.find(AccountLevel - 1, Config.AllowAccountLevel) == -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_AllowAccountLevel)
        end
        return 0
    end

    if Type == 1 then
        local LeftTime = ConfigReadNumber(Name, Data[1], _cache.dir .. "CacheConwtDown.cache")
        if LeftTime > os.time() then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_CountDown, {os.date("%A %I:%M:%S %p", LeftTime)})
            end
            return 0
        end

        local DayTimes = ConfigReadNumber(Name, Data[1], _cache.dir .. "CountDay.cache")
        if Config.DayTimes ~= nil and DayTimes >= Config.DayTimes[AccountLevel] then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_DayTimes)
            end
            return 0
        end
    end

    if Config.BlockMaps ~= nil and table.find(GetObjectMap(aIndex), Config.BlockMaps) ~= -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_BlockMaps)
        end
        return 0
    end

    if Config.AllowMaps ~= nil and table.find(GetObjectMap(aIndex), Config.AllowMaps) == -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_AllowMaps)
        end
        local Maps = {}
        for k, v in pairs(Config.AllowMaps) do
            table.insert(Maps, _map[v])
        end
        local msg = table.concat(Maps, ", ")
        if showMessage then
            NoticeSend(aIndex, 1, string.sub(msg, 1, 55))
        end
        if string.len(msg) > 55 then
            if showMessage then
                NoticeSend(aIndex, 1, string.sub(msg, 56, 110))
            end
        end
        if string.len(msg) > 110 then
            if showMessage then
                NoticeSend(aIndex, 1, string.sub(msg, 111, 155))
            end
        end
        return 0
    end

    if Config.BlockCoord ~= nil and _coord.checkMult(aIndex, Config.BlockCoord) == 1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_BlockCoord)
        end
        return 0
    end

    if Config.AllowCoord ~= nil and _coord.checkMult(aIndex, Config.AllowCoord) == 0 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_AllowCoord)
        end
        return 0
    end

    if Config.BlockDays ~= nil and table.find(os.date("*t").wday, Config.BlockDays) ~= -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_BlockDays)
        end
        return 0
    end

    if Config.BlockHours ~= nil and table.find(tonumber(os.date("%H")), Config.BlockHours) ~= -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_BlockHours)
        end
        return 0
    end

    local Level = GetObjectLevel(aIndex)
    if
        Config.AllowLevel ~= nil and
            (Level < Config.AllowLevel[AccountLevel][1] or Level > Config.AllowLevel[AccountLevel][2])
     then
        if showMessage then
            NoticeSend(
                aIndex,
                _strings.Controller_AllowLevel,
                {
                    Config.AllowLevel[AccountLevel][1],
                    Config.AllowLevel[AccountLevel][2]
                }
            )
        end
        return 0
    end

    if Season > 3 then
        local MasterLevel = GetObjectMasterLevel(aIndex)
        if
            Config.AllowMasterLevel ~= nil and
                (MasterLevel < Config.AllowMasterLevel[AccountLevel][1] or
                    MasterLevel > Config.AllowMasterLevel[AccountLevel][2])
         then
            if showMessage then
                NoticeSend(
                    aIndex,
                    _strings.Controller_AllowMasterLevel,
                    {
                        Config.AllowMasterLevel[AccountLevel][1],
                        Config.AllowMasterLevel[AccountLevel][2]
                    }
                )
            end
            return 0
        end
    end

    local Reset = GetObjectReset(aIndex)
    if
        Config.AllowReset ~= nil and
            (Reset < Config.AllowReset[AccountLevel][1] or Reset > Config.AllowReset[AccountLevel][2])
     then
        if showMessage then
            NoticeSend(
                aIndex,
                _strings.Controller_AllowReset,
                {
                    Config.AllowReset[AccountLevel][1],
                    Config.AllowReset[AccountLevel][2]
                }
            )
        end
        return 0
    end

    local MasterReset = GetObjectMasterReset(aIndex)
    if
        Config.AllowMasterReset ~= nil and
            (MasterReset < Config.AllowMasterReset[AccountLevel][1] or
                MasterReset > Config.AllowMasterReset[AccountLevel][2])
     then
        if showMessage then
            NoticeSend(
                aIndex,
                _strings.Controller_AllowMasterReset,
                {
                    Config.AllowMasterReset[AccountLevel][1],
                    Config.AllowMasterReset[AccountLevel][2]
                }
            )
        end
        return 0
    end

    if Config.AllowClass ~= nil and table.find(GetObjectClass(aIndex), Config.AllowClass) == -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_AllowClass)
        end
        return 0
    end

    if Config.AllowQuest ~= nil and table.find(GetObjectChangeUp(aIndex), Config.AllowQuest) == -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_AllowQuest)
        end
        return 0
    end

    if Config.AllowGuild ~= nil then
        local Guild = GetObjectGuildName(aIndex)
        if type(Config.AllowGuild) == "boolean" and Config.AllowGuild == false and Guild ~= "" then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_AllowGuild)
            end
            return 0
        elseif type(Config.AllowGuild) == "table" and #Config.AllowGuild == 0 and Guild == "" then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_AllowGuild)
            end
            return 0
        elseif
            type(Config.AllowGuild) == "table" and #Config.AllowGuild > 0 and table.find(Guild, Config.AllowGuild) == -1
         then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_AllowGuild)
            end
            return 0
        end
    end

    if Season > 4 then
        if Config.AllowGens ~= nil and table.find(GetObjectGensFamily(aIndex), Config.AllowGens) == -1 then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_AllowGens)
            end
            return 0
        end
    end

    if Config.AllowPKLevel ~= nil and table.find(GetObjectPKLevel(aIndex), Config.AllowPKLevel) == -1 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_AllowPKLevel)
        end
        return 0
    end

    if
        Config.AllowSafeZone ~= nil and Config.AllowSafeZone[AccountLevel] ~= true and
            MapCheckAttr(GetObjectMap(aIndex), GetObjectMapX(aIndex), GetObjectMapY(aIndex), 1) == 1
     then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_AllowSafeZone)
        end
        return 0
    end

    if Config.CheckInterface ~= nil and Config.CheckInterface == true and GetObjectInterface(aIndex) ~= 0 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_CheckInterface)
        end
        return 0
    end

    if
        Config.AllowNotSafeZone ~= nil and Config.AllowNotSafeZone[AccountLevel] ~= true and
            MapCheckAttr(GetObjectMap(aIndex), GetObjectMapX(aIndex), GetObjectMapY(aIndex), 1) == 0
     then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_AllowNotSafeZone)
        end
        return 0
    end

    if Config.ReqMoney ~= nil and GetObjectMoney(aIndex) < Config.ReqMoney[AccountLevel] then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_ReqMoney, {Config.ReqMoney[AccountLevel]})
        end
        return 0
    end

    if Season > 9 then
        if Config.ReqRuud ~= nil and GetObjectRuud(aIndex) < Config.ReqRuud[AccountLevel] then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_ReqRuud, {Config.ReqRuud[AccountLevel]})
            end
            return 0
        end
    end

    if Season > 3 and (Config.ReqWCoinC ~= nil or Config.ReqWCoinP ~= nil or Config.ReqGoblinPoint ~= nil) then
        local wc, wp, gp = CashShopGetPoint(aIndex)

        if Config.ReqWCoinC ~= nil and wc < Config.ReqWCoinC[AccountLevel] then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_ReqWCoinC, {Config.ReqWCoinC[AccountLevel]})
            end
            return 0
        end

        if Config.ReqWCoinP ~= nil and wp < Config.ReqWCoinP[AccountLevel] then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_ReqWCoinP, {Config.ReqWCoinP[AccountLevel]})
            end
            return 0
        end

        if Config.ReqGoblinPoint ~= nil and gp < Config.ReqGoblinPoint[AccountLevel] then
            if showMessage then
                NoticeSend(aIndex, _strings.Controller_ReqGoblinPoint, {Config.ReqGoblinPoint[AccountLevel]})
            end
            return 0
        end
    end

    if Config.ReqHuntPoint ~= nil and GetObjectHuntPoint(aIndex) < Config.ReqHuntPoint[AccountLevel] then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_ReqHuntPoint, {Config.ReqHuntPoint[AccountLevel]})
        end
        return 0
    end

    if Config.ReqInactive ~= nil and GetObjectHuntInactive(aIndex) < Config.ReqInactive[AccountLevel] then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_ReqInactive, {Config.ReqInactive[AccountLevel]})
        end
        return 0
    end

    if Config.ReqItem ~= nil then
        for k, v in pairs(Config.ReqItem[AccountLevel]) do
            if InventoryGetItemCount(aIndex, v[2], v[3]) < v[1] then
                if showMessage then
                    NoticeSend(
                        aIndex,
                        _strings.Controller_ReqItem,
                        {
                            v[1],
                            _item.name(v[2]),
                            (v[3] ~= -1 and "+" .. v[1] or "")
                        }
                    )
                end
                return 0
            end
        end
        interface = true
    end

    local ItemExSlots = {}

    if Config.ReqItemEx ~= nil then
        for k, v in pairs(Config.ReqItemEx[AccountLevel]) do
            local check = _item.check(aIndex, v, ItemExSlots)
            if check == 0 then
                if showMessage then
                    NoticeSend(aIndex, _strings.Controller_ReqItemEx, {v.Title})
                end
                return 0
            end
            table.insert(ItemExSlots, check)
        end
        interface = true
    end

    if Config.QueryCharacter ~= nil then
        for k, v in pairs(Config.QueryCharacter[AccountLevel]) do
            SQLQuery(string.format(v[1], GetObjectName(aIndex)))
            if SQLFetch() == 0 then
                SQLClose()
                if showMessage then
                    NoticeSend(aIndex, v[3])
                end
                return 0
            end
            SQLClose()
        end
    end

    if Config.QueryAccount ~= nil then
        for k, v in pairs(Config.QueryAccount[AccountLevel]) do
            SQLQuery(string.format(v[1], GetObjectAccount(aIndex)))
            if SQLFetch() == 0 then
                SQLClose()
                if showMessage then
                    NoticeSend(aIndex, v[3])
                end
                return 0
            end
            SQLClose()
        end
    end

    local CustomFunction, CustomFunctionCB = -1

    if Config.CustomFunction ~= nil then
        CustomFunction, CustomFunctionCB = Config.CustomFunction(aIndex, Data)
    end

    if CustomFunction == 0 then
        return 0
    end

    if interface == true and GetObjectInterface(aIndex) ~= 0 then
        if showMessage then
            NoticeSend(aIndex, _strings.Controller_CheckInterface)
        end
        return 0
    end

    local justCheck = false
    if Config.justCheck ~= nil then
        justCheck = Config.justCheck
    end

    if
        justCheck == false and
            ((Type == 1 and _G[Config.Function](aIndex, Data[1], Data[2]) == 1) or
                (Type == 2 and _G[Config.Function](Data, aIndex) == 1) or
                Type == 3)
     then
        if Config.ReqMoney ~= nil and Config.ReqMoney[AccountLevel] > 0 then
            local NewZen = (GetObjectMoney(aIndex) - Config.ReqMoney[AccountLevel])
            SetObjectMoney(aIndex, NewZen)
            MoneySend(aIndex, NewZen)
            NoticeSend(aIndex, _strings.Controller_ReqMoney_Debit, {Config.ReqMoney[AccountLevel]})
        end

        if Season > 9 then
            if Config.ReqRuud ~= nil and Config.ReqRuud[AccountLevel] > 0 then
                NoticeSend(aIndex, _strings.Controller_ReqRuud_Debit, {Config.ReqRuud[AccountLevel]})
                local NewRuud = (GetObjectRuud(aIndex) - Config.ReqRuud[AccountLevel])
                SetObjectRuud(aIndex, NewRuud)
                RuudSend(aIndex, NewRuud)
            end
        end

        if Season > 3 then
            if Config.ReqWCoinC ~= nil and Config.ReqWCoinC[AccountLevel] > 0 then
                CashShopSubPoint(aIndex, Config.ReqWCoinC[AccountLevel], 0, 0)
                NoticeSend(aIndex, _strings.Controller_ReqWCoinC_Rebit, {Config.ReqWCoinC[AccountLevel]})
            end

            if Config.ReqWCoinP ~= nil and Config.ReqWCoinP[AccountLevel] > 0 then
                CashShopSubPoint(aIndex, 0, Config.ReqWCoinP[AccountLevel], 0)
                NoticeSend(aIndex, _strings.Controller_ReqWCoinP_Debit, {Config.ReqWCoinP[AccountLevel]})
            end

            if Config.ReqGoblinPoint ~= nil and Config.ReqGoblinPoint[AccountLevel] > 0 then
                CashShopSubPoint(aIndex, 0, 0, Config.ReqGoblinPoint[AccountLevel])
                NoticeSend(aIndex, _strings.Controller_ReqGoblinPoint_Debit, {Config.ReqGoblinPoint[AccountLevel]})
            end
        end

        if Config.ReqHuntPoint ~= nil then
            SubObjectHuntPoint(aIndex, Config.ReqHuntPoint[AccountLevel])
            CalcObjectHuntPoint(aIndex)
            NoticeSend(aIndex, _strings.Controller_ReqHuntPoint_Debit, {Config.ReqHuntPoint[AccountLevel]})
        end

        if Config.ReqInactive ~= nil then
            SubObjectHuntInactive(aIndex, Config.ReqInactive[AccountLevel])
            NoticeSend(aIndex, _strings.Controller_ReqInactive_Debit, {Config.ReqInactive[AccountLevel]})
        end

        if Config.ReqItem ~= nil then
            for k, v in pairs(Config.ReqItem[AccountLevel]) do
                InventoryDelItemCount(aIndex, v[2], v[3], v[1])
                NoticeSend(aIndex, _strings.Controller_ReqItem_Debit, {v[1], _item.name(v[2])})
            end
        end

        for k, v in pairs(ItemExSlots) do
            local t = InventoryGetItemTable(aIndex, v)
            InventoryDelItemIndex(aIndex, v)
            NoticeSend(aIndex, _strings.Controller_ReqItemEx_Debit, {_item.name(t.Index)})
        end

        if Config.QueryCharacter ~= nil then
            for k, v in pairs(Config.QueryCharacter[AccountLevel]) do
                SQLQuery(string.format(v[2], GetObjectName(aIndex)))
                SQLClose()
            end
        end

        if Config.QueryAccount ~= nil then
            for k, v in pairs(Config.QueryAccount[AccountLevel]) do
                SQLQuery(string.format(v[2], GetObjectAccount(aIndex)))
                SQLClose()
            end
        end

        if CustomFunction == 1 then
            if type(CustomFunctionCB) == "function" then
                CustomFunctionCB(aIndex)
            end
        end

        if Type == 1 then
            if Config.CountDown ~= nil then
                ConfigSaveString(
                    Name,
                    Data[1],
                    (os.time() + Config.CountDown[AccountLevel]),
                    _cache.dir .. "CacheConwtDown.cache"
                )
            end

            if Config.DayTimes ~= nil then
                ConfigSaveString(Name, Data[1], DayTimes + 1, _cache.dir .. "CountDay.cache")
            end

            ConfigSaveString(
                GetObjectAccount(aIndex),
                os.date("%X") .. " " .. GetObjectName(aIndex),
                string.format(" %s | Vip: %d", Data[2], AccountLevel),
                _cache.dirDate() .. Config.Function .. ".log"
            )
        end
    end

    return 1
end
