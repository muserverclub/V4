G_EventLimitHWIDGlobal = {}
G_EventLimitHWIDEvent = {}
G_EventLimitIPGlobal = {}
G_EventLimitIPEvent = {}

BridgeFunctionAttach("OnNpcTalk", "G_Event_OnNpcTalk")
G_Event_OnNpcTalk = function(aIndex, bIndex)
	local Class = GetObjectClass(aIndex)

	if G_Event_List[Class] ~= nil then
		local Event = EventLimits[G_Event_List[Class][1]]

		if Event ~= nil then
			local Check, Value = G_EventCheckLimit(bIndex, G_Event_List[Class][1])

			if Check == 1 then
				ChatTargetSend(aIndex, bIndex, _strings.Event_Global_HWID_Limit, {Value})
				return 1
			elseif Check == 2 then
				ChatTargetSend(aIndex, bIndex, _strings._strings.Event_HWID_Limit, {Value})
				return 1
			elseif Check == 3 then
				ChatTargetSend(aIndex, bIndex, _strings.Event_Global_IP_Limit, {Value})
				return 1
			elseif Check == 4 then
				ChatTargetSend(aIndex, bIndex, _strings._strings.Event_IP_Limit, {Value})
				return 1
			elseif Check == 5 then
				ChatTargetSend(aIndex, bIndex, _strings.Event_Daily_Entrace_Limit, {Value})
				return 1
			end
		end
	end

	return 0
end

BridgeFunctionAttach("OnMapChange", "G_Event_OnMapChange")
G_Event_OnMapChange = function(aIndex, old, new)
	for k, v in pairs(G_Event_List) do
		for i, a in pairs(v[2]) do
			local list = {}
			if type(a) == "table" then
				for i = a[1], a[2] do
					table.insert(list, i)
				end
			else
				list = {a}
			end

			if table.find(new, list) ~= -1 then
				return G_EventApplyLimit(aIndex, v[1])
			elseif table.find(old, list) ~= -1 then
				return G_EventRemoveLimit(aIndex, v[1])
			end
		end
	end
end

BridgeFunctionAttach("OnCharacterClose", "G_Event_OnCharacterClose")
G_Event_OnCharacterClose = function(aIndex)
	for k, v in pairs(G_Event_List) do
		if table.find(GetObjectMap(aIndex), v[2]) ~= -1 then
			G_EventRemoveLimit(aIndex, v[1])
			break
		end
	end
end

G_EventCount = function(finder, List)
	local count = 0

	for k, v in pairs(List) do
		if v == finder then
			count = count + 1
		end
	end

	return count
end

G_EventRemoveLimit = function(aIndex, Event, EntryCount)
	local Config = EventLimits[Event]

	if Config ~= nil then
		local HWID = _user.hwid(aIndex)
		local IP = GetObjectIpAddress(aIndex)
		local VIP = GetObjectAccountLevel(aIndex) + 1

		if EventLimits.HWID > 0 and Config.IgnoreGlobalHWID[VIP] == false then
			G_EventLimitHWIDGlobal[aIndex] = nil
		end

		if Config.HWID > 0 then
			G_EventLimitHWIDEvent[Config.ID][aIndex] = nil
		end

		if EventLimits.IP > 0 and Config.IgnoreGlobalIP[VIP] == false then
			G_EventLimitIPGlobal[aIndex] = nil
		end

		if Config.IP > 0 then
			G_EventLimitIPEvent[Config.ID][aIndex] = nil
		end

		if Config.MaxEntrace[VIP] > 0 and EntryCount ~= nil then
			SQLQuery(
				"update EventEntryCount set EntryCount=EntryCount-1 WHERE Name='%s' and [Type]=%d",
				{
					GetObjectName(aIndex),
					Config.ID
				}
			)
		end
	end
end

G_EventApplyLimit = function(aIndex, Event)
	local Config = EventLimits[Event]

	if Config ~= nil then
		local HWID = _user.hwid(aIndex)
		local IP = GetObjectIpAddress(aIndex)
		local VIP = GetObjectAccountLevel(aIndex) + 1

		if EventLimits.HWID > 0 and Config.IgnoreGlobalHWID[VIP] == false then
			G_EventLimitHWIDGlobal[aIndex] = HWID
		end

		if Config.HWID > 0 then
			G_EventLimitHWIDEvent[Config.ID][aIndex] = HWID
		end

		if EventLimits.IP > 0 and Config.IgnoreGlobalIP[VIP] == false then
			G_EventLimitIPGlobal[aIndex] = IP
		end

		if Config.IP > 0 then
			G_EventLimitIPEvent[Config.ID][aIndex] = IP
		end

		local EventEntry = true
		for k, v in pairs(G_Event_List) do
			if v[1] == Event then
				EventEntry = v[3]
				break
			end
		end

		if EventEntry == true and Config.MaxEntrace[VIP] > 0 then
			SQLQuery("EXEC G_EventEntry '%s',%d", {GetObjectName(aIndex), Config.ID})
		end
	end
end

G_EventCheckLimit = function(aIndex, Event)
	local Config = EventLimits[Event]

	if Config ~= nil then
		local HWID = _user.hwid(aIndex)
		local IP = GetObjectIpAddress(aIndex)
		local VIP = GetObjectAccountLevel(aIndex) + 1

		if EventLimits.HWID > 0 and Config.IgnoreGlobalHWID[VIP] == false then
			local count = G_EventCount(HWID, G_EventLimitHWIDGlobal)
			if count >= EventLimits.HWID then
				return 1, EventLimits.HWID
			end
		end

		if Config.HWID > 0 then
			if G_EventLimitHWIDEvent[Config.ID] == nil then
				G_EventLimitHWIDEvent[Config.ID] = {}
			end
			local count = G_EventCount(HWID, G_EventLimitHWIDEvent[Config.ID])
			if count >= Config.HWID then
				return 2, Config.HWID
			end
		end

		if EventLimits.IP > 0 and Config.IgnoreGlobalIP[VIP] == false then
			local count = G_EventCount(IP, G_EventLimitIPGlobal)
			if count >= EventLimits.IP then
				return 4, EventLimits.IP
			end
		end

		if Config.IP > 0 then
			if G_EventLimitIPEvent[Config.ID] == nil then
				G_EventLimitIPEvent[Config.ID] = {}
			end
			local count = G_EventCount(IP, G_EventLimitIPEvent[Config.ID])
			if count >= Config.IP then
				return 5, Config.IP
			end
		end

		if Config.MaxEntrace[VIP] > 0 then
			local success, count =
				SQLQuery(
				"Select EntryCount from EventEntryCount WHERE Name='%s' and [Type]=%d",
				{
					GetObjectName(aIndex),
					Config.ID
				},
				{"EntryCount"}
			)

			if success ~= 0 and count >= Config.MaxEntrace[VIP] then
				return 3, Config.MaxEntrace[VIP]
			end
		end
	end

	return 0
end

G_EventCreateNPC = function(Config)
	Config.NPC = {}

	for k, v in pairs(Config.EntraceNPC) do
		local id = MonsterCreate(v.ID, v.Map, v.MapX, v.MapY, v.Dir)
		if id ~= nil then
			Config.NPC[id] = 1
		end
	end
end

G_EventDeleteNPC = function(Config)
	for k, v in pairs(Config.NPC) do
		MonsterDelete(k)
		Config.NPC[k] = nil
	end
end

G_EventNotice = function(Config, Message, Params)
	for k, v in pairs(Config.Player) do
		NoticeSend(k, Message, Params)
	end
end

G_EventInsertPermission = function(aIndex, Config)
	for k, v in pairs(Config.BlockSkill) do
		SetObjectSkillBlockTime(aIndex, v, 1)
	end
	PermissionInsert(aIndex, Config.RemovePermissions)
end

G_EventInsertPermissionAll = function(Config)
	for i, v in pairs(Config.Player) do
		G_EventInsertPermission(i, Config)
	end
end

G_EventRemovePermission = function(aIndex, Config)
	local timer = (Config.TimeAnnounce + Config.TimeStand + Config.TimeDuration) * 1000
	for k, v in pairs(Config.BlockSkill) do
		SetObjectSkillBlockTime(aIndex, v, timer)
	end
	PermissionRemove(aIndex, Config.RemovePermissions)
end

G_EventRemovePermissionAll = function(Config)
	for i, v in pairs(Config.Player) do
		G_EventRemovePermission(i, Config)
	end
end

G_EventMoveIn = function(aIndex, Config, Type)
	if Config.Region ~= nil and _coord.check(aIndex, Config.Region.Event) == 0 then
		local Map, MapX, MapY = _move.check(Config.Region.In)
		if Type == nil then
			MoveUserEx(aIndex, Map, MapX, MapY)
		else
			SetObjectMap(aIndex, Map)
			SetObjectMapX(aIndex, MapX)
			SetObjectMapY(aIndex, MapY)
		end
	end
end

G_EventMoveInAll = function(Config)
	for i, v in pairs(Config.Player) do
		G_EventMoveIn(i, Config)
	end
end

G_EventMoveOut = function(aIndex, Config, Type)
	if Config.Region ~= nil and _coord.check(aIndex, Config.Region.Event) == 1 then
		local Map, MapX, MapY = _move.check(Config.Region.Out)
		if Type == nil then
			MoveUserEx(aIndex, Map, MapX, MapY)
		else
			SetObjectMap(aIndex, Map)
			SetObjectMapX(aIndex, MapX)
			SetObjectMapY(aIndex, MapY)
		end
	end
end

G_EventMoveOutAll = function(Config)
	for i, v in pairs(Config.Player) do
		G_EventMoveOut(i, Config)
	end
end

G_EventInsertTimer = function(aIndex, Config)
	if Config.TimeAnnounce > 0 then
		TimerStartSend(aIndex, 0, 0, Config.TimeAnnounce * 1000)
	elseif Config.TimeStand > 0 then
		TimerStartSend(aIndex, 0, 0, Config.TimeStand * 1000)
	elseif Config.TimeDuration > 0 then
		TimerStartSend(aIndex, 0, 0, Config.TimeDuration * 1000)
	elseif Config.TimeFinish > 0 then
		TimerStartSend(aIndex, 0, 0, Config.TimeFinish * 1000)
	end
end

G_EventInsertTimerAll = function(Config)
	for i, v in pairs(Config.Player) do
		G_EventInsertTimer(i, Config)
	end
end

G_EventRemoveTimer = function(aIndex, Config)
	TimerStartSend(aIndex, 0, 0, 1000)
end

G_EventRemoveTimerAll = function(Config)
	for i, v in pairs(Config.Player) do
		G_EventRemoveTimer(i, Config)
	end
end

G_EventInsertSkin = function(aIndex, Config)
	if #Config.SetSkin ~= 0 then
		SkinChangeSend(aIndex, Config.SetSkin[RandomGetNumber(#Config.SetSkin) + 1])
	end
end

G_EventInsertSkinAll = function(Config)
	for i, v in pairs(Config.Player) do
		G_EventInsertSkin(i, Config)
	end
end

G_EventRemoveSkin = function(aIndex, Config)
	if #Config.SetSkin ~= 0 then
		SkinChangeSend(aIndex, -1)
	end
end

G_EventRemoveSkinAll = function(Config)
	for i, v in pairs(Config.Player) do
		G_EventRemoveTimer(i, Config)
	end
end

G_EventInsertPlayer = function(aIndex, Config, Respawn)
	G_EventMoveIn(aIndex, Config, Respawn)
	G_EventInsertTimer(aIndex, Config)
	G_EventInsertSkin(aIndex, Config)
	G_EventRemovePermission(aIndex, Config)
	if Respawn == nil and Config.Player[aIndex] == nil then
		Config.Player[aIndex] = {
			InsertDelay = 5
		}
	end
end

G_EventInsertPlayerAll = function(Config, Rewspawn)
	for k, v in pairs(Config.Player) do
		G_EventInsertPlayer(k, Config, Rewspawn)
	end
end

G_EventExec = function(Config, Prop, Params)
	if Config.Script ~= nil and _G[Config.Script][Prop] ~= nil then
		return _G[Config.Script][Prop](unpack(Params))
	end
end

G_EventRemovePlayer = function(aIndex, Config)
	G_EventExec(Config, "removePlayer", {aIndex, Config})
	G_EventRemoveTimer(aIndex, Config)
	G_EventRemoveSkin(aIndex, Config)
	G_EventInsertPermission(aIndex, Config)
	G_EventMoveOut(aIndex, Config)
	Config.Player[aIndex] = nil
end

G_EventRemovePlayerAll = function(Config)
	for k, v in pairs(Config.Player) do
		G_EventRemovePlayer(k, Config)
	end
end

G_EventCheckRequeriment = function(aIndex, Config)
	local running = false

	for k, v in pairs(Config.System) do
		if v.TimeAnnounce > 0 and v.TimeOpen == -1 then
			running = true
			if G_CheckRequeriments(aIndex, v.Requeriments, 0, "", Config.ShowRequeriment) ~= 0 then
				if table.count(v.Player) >= v.MaxPlayers then
					return 1, v
				end

				G_CheckRequeriments(aIndex, v.Requeriments, 3, "", false)
				return 0, v
			end
		end
	end

	for k, v in pairs(Config.System) do
		if G_CheckRequeriments(aIndex, v.Requeriments, 0, "", Config.ShowRequeriment) ~= 0 then
			if table.count(v.Player) >= v.MaxPlayers then
				return 4, v
			end

			return 5, v, function()
				G_CheckRequeriments(aIndex, v.Requeriments, 3, "", false)
			end
		end
	end

	return running == true and 2 or 3
end

G_EventCheckUsers = function(aIndex, bIndex, Config)
	for k, v in pairs(Config.System) do
		if v.Player[aIndex] ~= nil and v.Player[bIndex] ~= nil then
			return 0, v
		elseif v.Player[aIndex] ~= nil then
			return 2, v
		elseif v.Player[bIndex] ~= nil then
			return 3, v
		end
	end

	return 1
end

G_EventCheckMonster = function(aIndex, bIndex, Config)
	for k, v in pairs(Config.System) do
		if v.Monster[aIndex] ~= nil and v.Player[bIndex] ~= nil then
			return 0, v
		elseif v.Player[bIndex] ~= nil then
			return 2, v
		elseif v.Monster[aIndex] ~= nil then
			return 3, v
		end
	end

	return 1
end

G_EventCheckNpc = function(aIndex, bIndex, Config)
	for k, v in pairs(Config.System) do
		if v.Npc[aIndex] ~= nil and v.Player[bIndex] ~= nil then
			return 0, v
		elseif v.Player[bIndex] ~= nil then
			return 2, v
		elseif v.Npc[aIndex] ~= nil then
			return 3, v
		end
	end

	return 1
end

G_EventCheckArea = function(aIndex, Config)
	for k, v in pairs(Config.System) do
		if v.Region == nil then
			return true, v
		elseif _coord.check(aIndex, v.Region.Event) == 1 then
			return true, v
		end
	end
	return false
end

G_EventEnd = function(Config)
	G_EventRemovePlayerAll(Config)

	Config = nil
end

G_EventStage = function(Script, Config)
	local this = {}

	function this:checktime(k)
		local config = Config.List[k]

		if _time.startMult(config.Schedule.Fixed) ~= 0 then
			Config.System[k] = table.clone(config)
			Config.System[k].Player = {}
			Config.System[k].Monster = {}
			Config.System[k].Npc = {}
			Config.System[k].Region = config.Area[math.random(#config.Area)]
			Config.System[k].TimeOpen = math.random(config.Schedule.Random)
			Config.System[k].Script = Script
			Config.System[k].ID = k

			G_EventExec(Config.System[k], "startFixed", {Config.System[k]})
			LogColor(
				0,
				string.format(
					"[%s] %d will start at %s",
					Script,
					k,
					_time.format(os.date("*t", os.time() + Config.System[k].TimeOpen))
				)
			)
		end
	end

	function this:open(k)
		if Config.System[k].TimeOpen == 0 then
			G_EventExec(Config.System[k], "startRandom", {Config.System[k]})
			LogColor(0, string.format("[%s] %d announce started", Script, k))
		end

		Config.System[k].TimeOpen = Config.System[k].TimeOpen - 1
	end

	function this:announce(k)
		if Config.System[k].TimeAnnounce == Config.List[k].TimeAnnounce then
			LogColor(0, string.format("[%s] %d start announce", Script, k))
			G_EventExec(Config.System[k], "announceStart", {Config.System[k]})
		end

		if Config.System[k].TimeAnnounce > 0 and Config.System[k].TimeAnnounce % 60 == 0 then
			LogColor(3, string.format("[%s] %d announce %d minutes", Script, k, Config.System[k].TimeAnnounce / 60))
			G_EventExec(Config.System[k], "announceDiff", {Config.System[k]})
		end

		G_EventExec(Config.System[k], "announce", {Config.System[k]})
		Config.System[k].TimeAnnounce = Config.System[k].TimeAnnounce - 1
	end

	function this:stand(k)
		if Config.System[k].TimeStand == Config.List[k].TimeStand then
			if table.count(Config.System[k].Player) < Config.System[k].MinPlayers then
				G_EventExec(Config.System[k], "fewPlayers", {Config.System[k]})
				G_EventEnd(Config.System[k])
				Config.System[k] = nil
				LogColor(1, string.format("[%s] %d few players", Script, k))
				return 1
			end

			LogColor(0, string.format("[%s] %d start stand", Script, k))
			G_EventExec(Config.System[k], "standStart", {Config.System[k]})

			G_EventInsertTimerAll(Config.System[k])
		end

		if Config.System[k].TimeStand > 0 and Config.System[k].TimeStand % 60 == 0 then
			LogColor(3, string.format("[%s] %d stand %d minutes", Script, k, Config.System[k].TimeStand / 60))
			G_EventExec(Config.System[k], "standDiff", {Config.System[k]})
		end

		G_EventExec(Config.System[k], "stand", {Config.System[k]})
		Config.System[k].TimeStand = Config.System[k].TimeStand - 1
	end

	function this:duration(k)
		if Config.System[k].TimeDuration == Config.List[k].TimeDuration then
			LogColor(0, string.format("[%s] %d start duration", Script, k))
			G_EventExec(Config.System[k], "durationStart", {Config.System[k]})

			G_EventInsertTimerAll(Config.System[k])
		end

		if Config.System[k].TimeDuration > 0 and Config.System[k].TimeDuration % 60 == 0 then
			LogColor(3, string.format("[%s] %d duration %d minutes", Script, k, Config.System[k].TimeDuration / 60))
			G_EventExec(Config.System[k], "durationDiff", {Config.System[k]})
		end

		G_EventExec(Config.System[k], "duration", {Config.System[k]})
		Config.System[k].TimeDuration = Config.System[k].TimeDuration - 1
	end

	function this:finish(k)
		if Config.System[k].TimeFinish == Config.List[k].TimeFinish then
			LogColor(0, string.format("[%s] %d start finish", Script, k))
			G_EventExec(Config.System[k], "finishStart", {Config.System[k]})

			G_EventInsertTimerAll(Config.System[k])
			G_EventInsertPermissionAll(Config.System[k])
		end

		if Config.System[k].TimeFinish > 0 and Config.System[k].TimeFinish % 60 == 0 then
			LogColor(3, string.format("[%s] %d finish %d minutes", Script, k, Config.System[k].TimeFinish / 60))
			G_EventExec(Config.System[k], "finishDiff", {Config.System[k]})
		end

		G_EventExec(Config.System[k], "finish", {Config.System[k]})
		Config.System[k].TimeFinish = Config.System[k].TimeFinish - 1
	end

	function this:out(k)
		LogColor(0, string.format("[%s] %d out", Script, k))
		G_EventExec(Config.System[k], "out", {Config.System[k]})

		G_EventEnd(Config.System[k])
		Config.System[k] = nil
	end

	function this:outArea(k)
		for i, v in pairs(Config.System[k].Player) do
			if Config.System[k].Region ~= nil and _coord.check(i, Config.System[k].Region.Event) == 0 and v.InsertDelay == 0 then
				G_EventExec(Config.System[k], "outArea", {i, Config.System[k]})
			end
			if v.InsertDelay > 0 then
				v.InsertDelay = v.InsertDelay - 1
			end
		end
	end

	for k, v in pairs(Config.List) do
		if Config.System[k] ~= nil then
			this:outArea(k)

			G_EventExec(Config.System[k], "thread", {Config.System[k]})

			if Config.System[k].TimeOpen > -1 then
				this:open(k)
			elseif Config.System[k].TimeAnnounce > -1 then
				this:announce(k)
			elseif Config.System[k].TimeStand > -1 then
				this:stand(k)
			elseif Config.System[k].TimeDuration > -1 then
				this:duration(k)
			elseif Config.System[k].TimeFinish > -1 then
				this:finish(k)
			else
				this:out(k)
			end
		else
			this:checktime(k)
		end
	end

	if os.time() % 7 == 0 then
		for k, v in pairs(Config.NPC) do
			ChatTargetSend(k, -1, Config.Strings.npcTitle)
		end
	end
end
