_path.load = function(path, ext)
    local pipe = io.popen2(string.format([[powershell Get-ChildItem -Path '%s\*%s' -Recurse -Force]], path, ext))
    local Directory = nil
    local DirectoryStarted = false
    local Files = {}
    for k, v in pipe:lines() do
        local parsedir = table.concat({k:match("(%w):\\(.+)")}, ":\\")
        if DirectoryStarted == false and string.find(k, ":\\") ~= nil then
            Directory = parsedir
            DirectoryStarted = true
        elseif DirectoryStarted == true and Directory ~= nil then
            if k:gsub(" ", ""):gsub("\t", ""):len() == 0 then
                DirectoryStarted = false
            else
                Directory = Directory .. k:trim()
            end
        elseif Directory ~= nil and string.find(k, "%" .. ext) ~= nil and string.find(k, "%-a") ~= nil then
            Directory = Directory:gsub(path, "")
            if Directory:find("\\") == 1 then
                Directory = Directory:sub(2, -1)
            end

            if Files[Directory] == nil then
                Files[Directory] = {}
            end
            local parse =
                k:gsub(" AM", ""):gsub(" PM", ""):match(".+%s+%d+/%d+/%d+%s+%d+:%d+%s+%d+%s+(.+%" .. ext .. ")")
            if parse == nil then -- Fix peruano polones
                parse =
                    k:gsub(" AM", ""):gsub(" PM", ""):match(".+%s+%d+%.%d+%.%d+%s+%d+:%d+%s+%d+%s+(.+%" .. ext .. ")")
            end
            table.insert(Files[Directory], parse)
        end
    end
    pipe:close()
    return Files
end

_path.exists = function(sPath)
    if type(sPath) ~= "string" then
        return false
    end

    local response = os.execute("cd " .. sPath)
    if response == 0 then
        return true
    end
    return false
end

_path.gs = Folder_GS
_path.base = Folder_Base
_path.data = Folder_Data
_path.script = Folder_Script
