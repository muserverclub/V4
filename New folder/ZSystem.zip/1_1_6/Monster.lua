_monster.deleteList = {}

_monster.delete = function(aIndex, time)
    if time == nil then
        MonsterDelete(aIndex)
    else
        _monster.deleteList[aIndex] = os.time() + time
    end
end

_monster.exists = function(aValue, bValue)
    -- aValue = monster class
    -- bValue = if setted, aValue change to monster index
    -- return monster data

    if bValue ~= nil then
        if table.find(GetObjectType(aValue), {2, 3}) == -1 then
            return {}
        end

        aValue = GetObjectClass(aValue)
    end

    if _monster.list == nil then
        _monster.list = {}
        for k, v in pairs(_data["MONSTER_MONSTER"][-1]) do
            _monster.list[v[1]] = v
        end
    end

    if _monster.list[aValue] == nil then
        return {}
    end

    return _monster.list[aValue]
end

_monster.name = function(aValue, bValue)
    -- aValue = monster class
    -- bValue = if setted, aValue change to monster index
    -- return monster name
    local monster = _monster.exists(aValue, bValue)
    return monster[3] or ""
end
