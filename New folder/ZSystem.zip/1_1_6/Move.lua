_move.check = function(Area, Mode, Default)
    -- Return 0 > dentro e fora da cidade, 1 > apenas dentro da cidade, 2 > apenas fora da cidade
    if Mode == nil then
        Mode = 0
    end

    local MapX = 0
    local MapY = 0

    for i = 1, 500, 1 do
        local X = Area.MapXMin + RandomGetNumber(Area.MapXMax - Area.MapXMin)
        local Y = Area.MapYMin + RandomGetNumber(Area.MapYMax - Area.MapYMin)

        if Mode == 0 then -- Dentro e fora da cidade
            if
                MapCheckAttr(Area.Map, X, Y, 2) == 0 and MapCheckAttr(Area.Map, X, Y, 4) == 0 and
                    MapCheckAttr(Area.Map, X, Y, 8) == 0 and
                    MapCheckAttr(Area.Map, X, Y, 16) == 0
             then
                return Area.Map, X, Y, true
            end
        elseif Mode == 1 then -- dentro da cidade
            if MapCheckAttr(Area.Map, X, Y, 1) == 1 then
                return Area.Map, X, Y, true
            end
        elseif Mode == 2 then -- fora da cidade
            if
                MapCheckAttr(Area.Map, X, Y, 1) == 0 and MapCheckAttr(Area.Map, X, Y, 2) == 0 and
                    MapCheckAttr(Area.Map, X, Y, 4) == 0 and
                    MapCheckAttr(Area.Map, X, Y, 8) == 0 and
                    MapCheckAttr(Area.Map, X, Y, 16) == 0
             then
                return Area.Map, X, Y, true
            end
        end
    end

    if Default ~= nil and GetObjectName(Default) ~= "" then
        return GetObjectMap(Default), GetObjectMapX(Default), GetObjectMapY(Default), false
    end

    return 0, 125, 125, false
end

_move.checkMult = function(Area, Terrains)
    local area = RandomGetNumber(#Area) + 1

    return _move.check(Area[area], Terrains)
end

_move.send = function(aIndex, aValue, bValue, cValue)
    -- aValue = Move Table , Gate or Map
    -- bValue = MapX
    -- cValue = MapY
    if type(aValue) == "table" then
        if aValue.MapXMin ~= nil then
            local Map, MapX, MapY = _move.check(aValue, 0)
            MoveUserEx(aIndex, Map, MapX, MapY)
        else
            MoveUserEx(aIndex, aValue.Map, aValue.MapX, aValue.MapY)
        end
    elseif bValue == nil then
        MoveUser(aIndex, aValue)
    else
        MoveUserEx(aIndex, aValue, bValue, cValue)
    end
end

-- Support to old functions
G_CheckCoordMove = _move.check
G_CheckCoordMoveMult = _move.checkMult
