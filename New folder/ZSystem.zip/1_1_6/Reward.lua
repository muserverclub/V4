BridgeFunctionAttach("OnTimerThread", "G_Reward_OnTimerThread")
BridgeFunctionAttach("OnTimerThread", "G_Reward_OnTimerThread2")
BridgeFunctionAttach("OnReadScript", "G_Reward_OnReadScript")
BridgeFunctionAttach("OnShutScript", "G_Reward_OnShutScript")

G_RewardRateTable = {}

G_Reward_OnTimerThread2 = function()
    if os.time() % 300 == 0 then
        G_Reward_OnShutScript()
    end
end

G_Reward_OnReadScript = function()
    G_RewardRateTable = table.read(_cache.dir .. "REWARD_RATE_DATA.lua", "r") or {}
end

G_Reward_OnShutScript = function()
    table.print(G_RewardRateTable, _cache.dir .. "REWARD_RATE_DATA.lua", true)
end

G_RewardNoOwner = function(TargetIndex, Config, UserIndex)
    for k, v in pairs(BOT_LIST) do
        local BotIndex = GetObjectIndexByName(v)
        if BotIndex ~= -1 then
            G_RewardMake(BotIndex, TargetIndex, Config, UserIndex)
            return 1
        end
    end

    for BotIndex = GetMinUserIndex(), GetMaxUserIndex() do
        if GetObjectConnected(BotIndex) == 3 then
            if GetObjectMap(TargetIndex) ~= GetObjectMap(BotIndex) then
                G_RewardMake(BotIndex, TargetIndex, Config, UserIndex)
                break
            end
        end
    end
end

G_Reward = function(aIndex, Config)
    G_RewardMake(aIndex, aIndex, Config, aIndex)
end

G_RewardMake = function(BotIndex, TargetIndex, Config, UserIndex)
    local this = {
        ServerCode = GetGameServerCode(),
        DropCount = "",
        SectionRate = "",
        Type = "Normal",
        UserName = "",
        TargetName = GetObjectName(TargetIndex),
        Vip = 0
    }

    local BagName = Config.BagName

    if BagName ~= nil and G_RewardBag[BagName] ~= nil then
        Config = G_RewardBag[BagName]
        Config.BagName = BagName
    end

    if UserIndex == nil or BotIndex ~= UserIndex then
        this.Type = "NoOwner"
    end

    if UserIndex ~= nil then
        this.UserName = GetObjectName(UserIndex)
        this.Vip = GetObjectAccountLevel(UserIndex)
    end

    if GetObjectType(TargetIndex) ~= 1 then
        this.TargetName = G_Monster[GetObjectClass(TargetIndex)][3]
    end

    local MapNumber = GetObjectMap(TargetIndex)
    local MapX = GetObjectMapX(TargetIndex)
    local MapY = GetObjectMapY(TargetIndex)

    local Map = {
        Map = MapNumber,
        MapXMin = MapX - 3,
        MapXMax = MapX + 3,
        MapYMin = MapY - 3,
        MapYMax = MapY + 3
    }

    local GetBagName = function(arg)
        return table.concat({BagName, unpack(arg)}, "_")
    end

    local GetRate = function(rate)
        if type(rate) == "number" then
            return rate
        end

        if Config.MaxRate == nil then
            return 100
        else
            return Config.MaxRate
        end
    end

    local MakeRate = function(Conf, MaxRate)
        if MaxRate == nil then
            if Config.MaxRate == nil then
                MaxRate = 100
            else
                MaxRate = Config.MaxRate
            end
        end

        local Bag = GetBagName(Conf)

        if Bag == "" then
            return MaxRate
        end

        if G_RewardRateTable[Bag] == nil or #G_RewardRateTable[Bag] == 0 then
            G_RewardRateTable[Bag] = {}
            for i = 1, MaxRate do
                table.insert(G_RewardRateTable[Bag], i)
            end
        end

        local Random = math.random(#G_RewardRateTable[Bag])
        local Rate = G_RewardRateTable[Bag][Random]
        table.remove(G_RewardRateTable[Bag], Random)

        return Rate
    end

    local MakeDrop = function(rate)
        local list = {}
        local total = 0

        for k, v in pairs(rate) do
            total = total + GetRate(v)
            table.insert(list, {total, k})
        end

        return total, list
    end

    local SendDrop = function(Conf)
        if Conf.Vip ~= nil then
            if Conf.Vip[this.Vip] ~= nil then
                G_RewardSend(BotIndex, UserIndex, Conf.Vip[this.Vip], Map)
            end
        else
            G_RewardSend(BotIndex, UserIndex, Conf, Map)
        end

        if BagName ~= nil then
            SQLQuery(
                ([[
                INSERT INTO MSC_REWARD_LOG 
                (ServerCode,
                BagName,
                CountDrop,
                SectionRate,
                Type,
                UserName,
                TargetName,
                Vip)
                VALUES
                (%d,'%s','%s','%s','%s','%s','%s',%d)
            ]]),
                {
                    this.ServerCode,
                    BagName,
                    this.DropCount,
                    this.SectionRate,
                    this.Type,
                    this.UserName,
                    this.TargetName,
                    this.Vip
                }
            )
        end
    end

    if BagName == nil then
        SendDrop(Config)
    elseif Config.DropCount == nil then
        if Config.SectionRate == nil then
            SendDrop(Config)
        else
            local DropRate, DropList = MakeDrop(Config.SectionRate)
            local Rate = MakeRate({"Section"}, DropRate)
            for k, v in pairs(DropList) do
                if Rate <= v[1] then
                    this.SectionRate = v[2]
                    SendDrop(Config[v[2]])

                    break
                end
            end
        end
    else
        for k, v in pairs(Config.DropCount) do
            local DropCount = MakeRate({k})

            if DropCount <= GetRate(v) then
                if Config[k].SectionRate == nil then
                    this.DropCount = k
                    SendDrop(Config[k])
                else
                    local DropRate, DropList, DropMax = MakeDrop(Config[k].SectionRate)
                    local Rate = MakeRate({k, "Section"}, DropRate)

                    for i, a in pairs(DropList) do
                        if Rate <= a[1] then
                            this.DropCount = k
                            this.SectionRate = a[2]
                            SendDrop(Config[k][a[2]])

                            break
                        end
                    end
                end
            end
        end
    end
end

G_RewardSend = function(DropIndex, UserIndex, Config, Map)
    local GetRandom = function(conf)
        if type(conf) == "table" then
            return math.random({Min = conf[1], Max = conf[2]})
        elseif type(conf) == "number" then
            return conf
        end
        return 0
    end

    local Send = function(Config)
        if Config.Item ~= nil and #Config.Item > 0 then
            for k, v in pairs(Config.Item) do
                G_RewardItem(DropIndex, v, Map, "drop", UserIndex)
            end
        end
        if Config.ItemGive ~= nil and #Config.ItemGive > 0 then
            for k, v in pairs(Config.ItemGive) do
                G_RewardItem(DropIndex, v, Map, "give", UserIndex)
            end
        end
        if Config.ItemGiveDb ~= nil and #Config.ItemGiveDb > 0 then
            for k, v in pairs(Config.ItemGiveDb) do
                G_RewardItem(DropIndex, v, Map, "db", UserIndex)
            end
        end
        if Config.SpecialEventBag ~= nil and #Config.SpecialEventBag > 0 then
            for k, v in pairs(Config.SpecialEventBag) do
                G_RewardBag(DropIndex, v, Map, UserIndex)
            end
        end
        if Config.SpecialEventBagGive ~= nil and #Config.SpecialEventBagGive > 0 then
            for k, v in pairs(Config.SpecialEventBagGive) do
                ItemGive(DropIndex, v)
                NoticeSend(DropIndex, _strings.Reward_Item_Send_To_Inventory)
            end
        end
        if Config.Summon ~= nil and #Config.Summon > 0 then
            for k, v in pairs(Config.Summon) do
                G_RewardSummon(DropIndex, v, Map, UserIndex)
            end
        end
        if Config.RandomItemGive ~= nil and #Config.RandomItemGive > 0 then
            local conf = Config.RandomItemGive[math.random(#Config.RandomItemGive)]
            G_RewardItem(DropIndex, conf, Map, "give", UserIndex)
        end
        if Config.RandomItem ~= nil and #Config.RandomItem > 0 then
            local conf = Config.RandomItem[math.random(#Config.RandomItem)]
            G_RewardItem(DropIndex, conf, Map, "drop")
        end
        if Config.RandomItemGiveDb ~= nil and #Config.RandomItemGiveDb > 0 then
            local conf = Config.RandomItemGiveDb[math.random(#Config.RandomItemGiveDb)]
            G_RewardItem(DropIndex, conf, Map, "db", UserIndex)
        end
        if Config.RandomSpecialEventBag ~= nil and #Config.RandomSpecialEventBag > 0 then
            local conf = Config.RandomSpecialEventBag[math.random(#Config.RandomSpecialEventBag)]
            G_RewardBag(DropIndex, conf, Map, UserIndex)
        end
        if Config.RandomSpecialEventBagGive ~= nil and #Config.RandomSpecialEventBagGive > 0 then
            local conf = Config.RandomSpecialEventBagGive[math.random(#Config.RandomSpecialEventBagGive)]
            ItemGive(DropIndex, conf)
            NoticeSend(DropIndex, _strings.Reward_Item_Send_To_Inventory)
        end
        if Config.RandomSummon ~= nil and #Config.RandomSummon > 0 then
            local conf = Config.RandomSummon[math.random(#Config.RandomSummon)]
            G_RewardSummon(DropIndex, conf, Map, UserIndex)
        end
        if Config.Function ~= nil then
            Config.Function(DropIndex)
        end
        if DropIndex == UserIndex then
            if Config.Effect ~= nil and #Config.Effect > 0 then
                for k, v in pairs(Config.Effect) do
                    G_RewardEffect(DropIndex, v)
                end
            end
            if Config.RandomEffect ~= nil and #Config.RandomEffect > 0 then
                local conf = Config.RandomEffect[math.random(#Config.RandomEffect)]
                G_RewardEffect(DropIndex, conf)
            end
            if _G["CashShopGetPoint"] ~= nil then
                local WCoinC = GetRandom(Config.WCoinC)
                if WCoinC > 0 then
                    G_RewardWCoinC(DropIndex, WCoinC)
                end
                if Config.RandomWCoinC ~= nil and #Config.RandomWCoinC > 0 then
                    local conf = Config.RandomWCoinC[math.random(#Config.RandomWCoinC)]

                    local WCoinC = GetRandom(conf)
                    if WCoinC > 0 then
                        G_RewardWCoinC(DropIndex, WCoinC)
                    end
                end
                local WCoinP = GetRandom(Config.WCoinP)
                if WCoinP > 0 then
                    G_RewardWCoinP(DropIndex, WCoinP)
                end
                if Config.RandomWCoinP ~= nil and #Config.RandomWCoinP > 0 then
                    local conf = Config.RandomWCoinP[math.random(#Config.RandomWCoinP)]

                    local WCoinP = GetRandom(conf)
                    if WCoinP > 0 then
                        G_RewardWCoinP(DropIndex, WCoinP)
                    end
                end
                local GoblinPoint = GetRandom(Config.GoblinPoint)
                if GoblinPoint > 0 then
                    G_RewardGoblinPoint(DropIndex, GoblinPoint)
                end
                if Config.RandomGoblinPoint ~= nil and #Config.RandomGoblinPoint > 0 then
                    local conf = Config.RandomGoblinPoint[math.random(#Config.RandomGoblinPoint)]

                    local GoblinPoint = GetRandom(conf)
                    if GoblinPoint > 0 then
                        G_RewardGoblinPoint(DropIndex, GoblinPoint)
                    end
                end
                if _G["HuntPoint"] ~= nil then
                    local HuntPoint = GetRandom(Config.HuntPoint)
                    if HuntPoint > 0 then
                        G_RewardHuntPoint(DropIndex, HuntPoint)
                    end
                    if Config.RandomHuntPoint ~= nil and #Config.RandomHuntPoint > 0 then
                        local conf = Config.RandomHuntPoint[math.random(#Config.RandomHuntPoint)]

                        local HuntPoint = GetRandom(conf)
                        if HuntPoint > 0 then
                            G_RewardHuntPoint(DropIndex, HuntPoint)
                        end
                    end

                    local Inactive = GetRandom(Config.Inactive)
                    if Inactive > 0 then
                        G_RewardInactive(DropIndex, Inactive)
                    end
                    if Config.RandomInactive ~= nil and #Config.RandomInactive > 0 then
                        local conf = Config.RandomInactive[math.random(#Config.RandomInactive)]

                        local Inactive = GetRandom(conf)
                        if Inactive > 0 then
                            G_RewardInactive(DropIndex, Inactive)
                        end
                    end
                end
            end
            if _G["GetObjectRuud"] ~= nil then
                local Ruud = GetRandom(Config.Ruud)
                if Ruud > 0 then
                    G_RewardRuud(DropIndex, Ruud)
                end
                if Config.RandomRuud ~= nil and #Config.RandomRuud > 0 then
                    local conf = Config.RandomRuud[math.random(#Config.RandomRuud)]

                    local Ruud = GetRandom(conf)
                    if Ruud > 0 then
                        G_RewardRuud(DropIndex, Ruud)
                    end
                end
            end
            local Money = GetRandom(Config.Money)
            if Money > 0 then
                G_RewardMoney(DropIndex, Money)
            end
            if Config.RandomMoney ~= nil and #Config.RandomMoney > 0 then
                local conf = Config.RandomMoney[math.random(#Config.RandomMoney)]

                local Money = GetRandom(conf)
                if Money > 0 then
                    G_RewardMoney(DropIndex, Money)
                end
            end
            if _G["AddObjectExperience"] ~= nil then
                local Experience = GetRandom(Config.Experience)
                if Experience > 0 then
                    AddObjectExperience(DropIndex, Experience)
                end
                if Config.RandomExperience ~= nil and #Config.RandomExperience > 0 then
                    local conf = Config.RandomExperience[math.random(#Config.RandomExperience)]

                    local Experience = GetRandom(conf)
                    if Experience > 0 then
                        AddObjectExperience(DropIndex, Experience)
                    end
                end
            end
            if Config.QueryAccount ~= nil and #Config.QueryAccount > 0 then
                for k, v in pairs(Config.QueryAccount) do
                    G_RewardQueryAccount(DropIndex, v)
                end
            end
            if Config.RandomQueryAccount ~= nil and #Config.RandomQueryAccount > 0 then
                local conf = Config.RandomQueryAccount[math.random(#Config.RandomQueryAccount)]
                G_RewardQueryAccount(DropIndex, conf)
            end
            if Config.QueryCharacter ~= nil and #Config.QueryCharacter > 0 then
                for k, v in pairs(Config.QueryCharacter) do
                    G_RewardQueryCharacter(DropIndex, v)
                end
            end
            if Config.RandomQueryCharacter ~= nil and #Config.RandomQueryCharacter > 0 then
                local conf = Config.RandomQueryCharacter[math.random(#Config.RandomQueryCharacter)]
                G_RewardQueryCharacter(DropIndex, conf)
            end
        end
    end

    if Config.Random == nil or Config.Random == 0 then
        Send(Config)
    else
        for i = 1, Config.Random do
            for a = 1, 1000 do
                local Radom = math.random(34)

                if Radom == 0 and Config.Item ~= nil and #Config.Item > 0 then
                    Send({Item = Config.Item})
                    break
                end
                if Radom == 1 and Config.ItemGive ~= nil and #Config.ItemGive > 0 then
                    Send({ItemGive = Config.ItemGive})
                    break
                end
                if Radom == 2 and Config.ItemGiveDb ~= nil and #Config.ItemGiveDb > 0 then
                    Send({ItemGiveDb = Config.ItemGiveDb})
                    break
                end
                if Radom == 3 and Config.SpecialEventBag ~= nil and #Config.SpecialEventBag > 0 then
                    Send({SpecialEventBag = Config.SpecialEventBag})
                    break
                end
                if Radom == 4 and Config.SpecialEventBagGive ~= nil and #Config.SpecialEventBagGive > 0 then
                    Send({SpecialEventBagGive = Config.SpecialEventBagGive})
                    break
                end
                if Radom == 5 and Config.Summon ~= nil and #Config.Summon > 0 then
                    Send({Summon = Config.Summon})
                    break
                end
                if Radom == 6 and Config.RandomItemGive ~= nil and #Config.RandomItemGive > 0 then
                    Send({RandomItemGive = Config.RandomItemGive})
                    break
                end
                if Radom == 7 and Config.RandomItem ~= nil and #Config.RandomItem > 0 then
                    Send({RandomItem = Config.RandomItem})
                    break
                end
                if Radom == 8 and Config.RandomItemGiveDb ~= nil and #Config.RandomItemGiveDb > 0 then
                    Send({RandomItemGiveDb = Config.RandomItemGiveDb})
                    break
                end
                if Radom == 9 and Config.RandomSpecialEventBag ~= nil and #Config.RandomSpecialEventBag > 0 then
                    Send({RandomSpecialEventBag = Config.RandomSpecialEventBag})
                    break
                end
                if Radom == 10 and Config.RandomSpecialEventBagGive ~= nil and #Config.RandomSpecialEventBagGive > 0 then
                    Send(
                        {
                            RandomSpecialEventBagGive = Config.RandomSpecialEventBagGive
                        }
                    )
                    break
                end
                if Radom == 11 and Config.RandomSummon ~= nil and #Config.RandomSummon > 0 then
                    Send({RandomSummon = Config.RandomSummon})
                    break
                end
                if DropIndex == UserIndex then
                    if Radom == 30 and Config.Function ~= nil then
                        Send({Function = Config.Function})
                        break
                    end
                    if Radom == 12 and Config.Effect ~= nil and #Config.Effect > 0 then
                        Send({Effect = Config.Effect})
                        break
                    end
                    if Radom == 13 and Config.RandomEffect ~= nil and #Config.RandomEffect > 0 then
                        Send({RandomEffect = Config.RandomEffect})
                        break
                    end
                    if _G["CashShopGetPoint"] ~= nil then
                        if Radom == 14 and Config.WCoinC ~= nil then
                            Send({WCoinC = Config.WCoinC})
                            break
                        end
                        if Radom == 15 and Config.RandomWCoinC ~= nil and #Config.RandomWCoinC > 0 then
                            Send({RandomWCoinC = Config.RandomWCoinC})
                            break
                        end
                        if Radom == 16 and Config.WCoinP ~= nil and Config.WCoinP > 0 then
                            Send({WCoinP = Config.WCoinP})
                            break
                        end
                        if Radom == 17 and Config.RandomWCoinP ~= nil and #Config.RandomWCoinP > 0 then
                            Send({RandomWCoinP = Config.RandomWCoinP})
                            break
                        end
                        if Radom == 18 and Config.GoblinPoint ~= nil and Config.GoblinPoint > 0 then
                            Send({GoblinPoint = Config.GoblinPoint})
                            break
                        end
                        if Radom == 19 and Config.RandomGoblinPoint ~= nil and #Config.RandomGoblinPoint > 0 then
                            Send({RandomGoblinPoint = Config.RandomGoblinPoint})
                            break
                        end
                    end
                    if _G["HuntPoint"] ~= nil then
                        if Radom == 31 and Config.HuntPoint ~= nil and Config.HuntPoint > 0 then
                            Send({HuntPoint = Config.HuntPoint})
                            break
                        end
                        if Radom == 32 and Config.RandomHuntPoint ~= nil and #Config.RandomHuntPoint > 0 then
                            Send({RandomHuntPoint = Config.RandomHuntPoint})
                            break
                        end

                        if Radom == 33 and Config.Inactive ~= nil and Config.Inactive > 0 then
                            Send({Inactive = Config.Inactive})
                            break
                        end
                        if Radom == 34 and Config.RandomInactive ~= nil and #Config.RandomInactive > 0 then
                            Send({RandomInactive = Config.RandomInactive})
                            break
                        end
                    end
                    if Radom == 20 and Config.QueryAccount ~= nil and #Config.QueryAccount > 0 then
                        Send({QueryAccount = Config.QueryAccount})
                        break
                    end
                    if Radom == 21 and Config.QueryAccountRandom ~= nil and #Config.QueryAccountRandom > 0 then
                        Send({QueryAccountRandom = Config.QueryAccountRandom})
                        break
                    end
                    if Radom == 22 and Config.QueryCharacter ~= nil and #Config.QueryCharacter > 0 then
                        Send({QueryCharacter = Config.QueryCharacter})
                        break
                    end
                    if Radom == 23 and Config.QueryCharacterRandom ~= nil and #Config.QueryCharacterRandom > 0 then
                        Send(
                            {
                                QueryCharacterRandom = Config.QueryCharacterRandom
                            }
                        )
                        break
                    end
                    if _G["GetObjectRuud"] ~= nil then
                        if Radom == 24 and Config.Ruud ~= nil and Config.Ruud > 0 then
                            Send({Ruud = Config.Ruud})
                            break
                        end
                        if Radom == 25 and Config.RandomRuud ~= nil and #Config.RandomRuud > 0 then
                            Send({RandomRuud = Config.RandomRuud})
                            break
                        end
                    end
                    if Radom == 26 and Config.Money ~= nil and Config.Money > 0 then
                        Send({Money = Config.Money})
                        break
                    end
                    if Radom == 27 and Config.RandomMoney ~= nil and #Config.RandomMoney > 0 then
                        Send({RandomMoney = Config.RandomMoney})
                        break
                    end
                    if _G["AddObjectExperience"] ~= nil then
                        if Radom == 28 and Config.Experience ~= nil and Config.Experience > 0 then
                            Send({Experience = Config.Experience})
                        end
                        if Radom == 29 and Config.RandomExperience ~= nil and #Config.RandomExperience > 0 then
                            Send({RandomExperience = Config.RandomExperience})
                        end
                    end
                end
            end
        end
    end
end

G_RewardItem = function(aIndex, Config, Map, Type, LocationIndex)
    local Config = table.clone(Config)

    Config.Section = Config.Section == nil and 0 or Config.Section
    Config.ID = Config.ID == nil and 0 or Config.ID
    Config.Excellent1 = Config.Excellent1 == nil and 0 or Config.Excellent1
    Config.Excellent2 = Config.Excellent2 == nil and 0 or Config.Excellent2
    Config.Excellent3 = Config.Excellent3 == nil and 0 or Config.Excellent3
    Config.Excellent4 = Config.Excellent4 == nil and 0 or Config.Excellent4
    Config.Excellent5 = Config.Excellent5 == nil and 0 or Config.Excellent5
    Config.Excellent6 = Config.Excellent6 == nil and 0 or Config.Excellent6
    Config.Harmony = Config.Harmony == nil and 0 or Config.Harmony
    Config.HarmonyLevel = Config.HarmonyLevel == nil and 0 or Config.HarmonyLevel
    Config.Option380 = Config.Option380 == nil and 0 or Config.Option380
    Config.Socket1 = Config.Socket1 == nil and 255 or Config.Socket1
    Config.Socket2 = Config.Socket2 == nil and 255 or Config.Socket2
    Config.Socket3 = Config.Socket3 == nil and 255 or Config.Socket3
    Config.Socket4 = Config.Socket4 == nil and 255 or Config.Socket4
    Config.Socket5 = Config.Socket5 == nil and 255 or Config.Socket5
    Config.Socket1Level = Config.Socket1Level == nil and 0 or Config.Socket1Level
    Config.Socket2Level = Config.Socket2Level == nil and 0 or Config.Socket2Level
    Config.Socket3Level = Config.Socket3Level == nil and 0 or Config.Socket3Level
    Config.Socket4Level = Config.Socket4Level == nil and 0 or Config.Socket4Level
    Config.Socket5Level = Config.Socket5Level == nil and 0 or Config.Socket5Level
    Config.SocketBonus = Config.SocketBonus == nil and 0 or Config.SocketBonus
    Config.Duration = Config.Duration == nil and 0 or Config.Duration
    Config.Durability = Config.Durability == nil and 0 or Config.Durability
    Config.Level = Config.Level == nil and 0 or Config.Level
    Config.Skill = Config.Skill == nil and 0 or Config.Skill
    Config.Luck = Config.Luck == nil and 0 or Config.Luck
    Config.Option = Config.Option == nil and 0 or Config.Option
    Config.Ancient = Config.Ancient == nil and 0 or Config.Ancient
    Config.Coment = Config.Coment == nil and "" or Config.Coment

    local Index = (Config.Section * 512 + Config.ID)
    local Excellent = 0
    Excellent = Excellent + (Config.Excellent1 ~= 0 and 1 or 0)
    Excellent = Excellent + (Config.Excellent2 ~= 0 and 2 or 0)
    Excellent = Excellent + (Config.Excellent3 ~= 0 and 4 or 0)
    Excellent = Excellent + (Config.Excellent4 ~= 0 and 8 or 0)
    Excellent = Excellent + (Config.Excellent5 ~= 0 and 16 or 0)
    Excellent = Excellent + (Config.Excellent6 ~= 0 and 32 or 0)
    local Harmony = Config.HarmonyLevel + (Config.Harmony * 16)
    local Option380 = (Config.Option380 ~= 0 and 128 or 0)
    local Socket1 = Config.Socket1 + (Config.Socket1Level * 50)
    local Socket2 = Config.Socket2 + (Config.Socket2Level * 50)
    local Socket3 = Config.Socket3 + (Config.Socket3Level * 50)
    local Socket4 = Config.Socket4 + (Config.Socket4Level * 50)
    local Socket5 = Config.Socket5 + (Config.Socket5Level * 50)
    local Duration = Config.Duration
    local Owner = (Config.Owner ~= 0 and aIndex or 0)

    if Type == "give" then
        local conf = {
            aIndex,
            Index,
            Config.Level,
            Config.Durability,
            Config.Skill,
            Config.Luck,
            Config.Option,
            Excellent,
            Config.Ancient,
            Harmony,
            Option380,
            Socket1,
            Socket2,
            Socket3,
            Socket4,
            Socket5,
            Config.SocketBonus,
            Duration
        }

        ItemGiveEx(unpack(conf))
        NoticeSend(aIndex, _strings.Reward_Item_Name_Send_To_Inventory, {_item.name(Index)})
    elseif Type == "drop" then
        local Map, MapX, MapY, Found = _move.check(Map, 0, LocationIndex)

        local conf = {
            aIndex,
            Map,
            MapX,
            MapY,
            Index,
            Config.Level,
            Config.Durability,
            Config.Skill,
            Config.Luck,
            Config.Option,
            Excellent,
            Config.Ancient,
            Harmony,
            Option380,
            Socket1,
            Socket2,
            Socket3,
            Socket4,
            Socket5,
            Config.SocketBonus,
            Duration,
            Owner
        }

        ItemDropEx(unpack(conf))
    elseif Type == "db" then
        SQLQuery(
            "INSERT INTO Greed_Reward ([Name],[Type],[Index],[Durability],[Level],[Option1],[Option2],[Option3],[NewOption],[setoption],[380option],[johoption],[socketoption1],[socketoption2],[socketoption3],[socketoption4],[socketoption5],[duration],[socketoptionbonus],[comment]) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s') ",
            {
                GetObjectName(aIndex),
                "item",
                Index,
                Config.Durability,
                Config.Level,
                Config.Skill,
                Config.Luck,
                Config.Option,
                Excellent,
                Config.Ancient,
                Option380,
                Harmony,
                Socket1,
                Socket2,
                Socket3,
                Socket4,
                Socket5,
                Duration,
                Config.SocketBonus,
                Config.Coment
            }
        )
    end
end

G_RewardBag = function(aIndex, Config, Map, LocationIndex)
    local Map, MapX, MapY, Found = _move.check(Map, 0, LocationIndex)
    ItemDrop(aIndex, Map, MapX, MapY, Config)
end

G_RewardSummon = function(aIndex, Config, Map, LocationIndex)
    local Map, MapX, MapY, Found = _move.check(Map, 2, LocationIndex)
    local id = MonsterCreate(Config, Map, MapX, MapY, -1)

    if id ~= nil then
        NoticeSend(aIndex, 1, "Monster nos created: " .. tostring(Config))
    end
    NoticeSend(aIndex, _strings.Reward_Monster_Summon, {G_Monster[Config][3]})
end

G_RewardEffect = function(aIndex, Config)
    local conf = {
        aIndex,
        Config.Mode,
        Config.Index,
        Config.Time,
        Config.Value1,
        Config.Value2,
        Config.Value3,
        Config.Value4
    }
    EffectAdd(unpack(conf))

    NoticeSend(aIndex, _strings.Reward_Effect_Receive, {G_LoadEffect[Config.Index][4]})
end

G_RewardHuntPoint = function(aIndex, Config)
    if Config ~= 0 then
        AddObjectHuntPoint(aIndex, Config)
        CalcObjectHuntPoint(aIndex)
    end
end

G_RewardInactive = function(aIndex, Config)
    if Config ~= 0 then
        AddObjectHuntInactive(aIndex, Config)
    end
end

G_RewardWCoinC = function(aIndex, Config)
    if Config ~= 0 then
        CashShopAddPoint(aIndex, Config, 0, 0)

        NoticeSend(aIndex, _strings.Reward_WCoinC_Receive, {Config})
    end
end

G_RewardWCoinP = function(aIndex, Config)
    if Config ~= 0 then
        CashShopAddPoint(aIndex, 0, Config, 0)

        NoticeSend(aIndex, _strings.Reward_WCoinP_Receive, {Config})
    end
end

G_RewardGoblinPoint = function(aIndex, Config)
    if Config ~= 0 then
        CashShopAddPoint(aIndex, 0, 0, Config)

        NoticeSend(aIndex, _strings.Reward_GoblinPoint_Receive, {Config})
    end
end

G_RewardRuud = function(aIndex, Config)
    if Config ~= 0 then
        SetObjectRuud(aIndex, (GetObjectRuud(aIndex) + Config))
        RuudSend(aIndex, Config)
    end
end

G_RewardMoney = function(aIndex, Config)
    if Config ~= 0 then
        SetObjectMoney(aIndex, (GetObjectMoney(aIndex) + Config))
        MoneySend(aIndex, GetObjectMoney(aIndex))
    end
end

G_RewardQueryAccount = function(aIndex, Config)
    local query = string.format(Config[1], GetObjectAccount(aIndex))
    SQLQuery(query)
    SQLClose()
    NoticeSend(aIndex, 1, Config[2])
end

G_RewardQueryCharacter = function(aIndex, Config)
    local query = string.format(Config[1], GetObjectName(aIndex))
    SQLQuery(query)
    SQLClose()
    NoticeSend(aIndex, 1, Config[2])
end

G_Reward_OnTimerThread = function()
    if os.date("*t").sec % 2 == 0 then
        for aIndex, v in pairs(CharacterBridge) do
            if GetObjectConnected(aIndex) == 3 then
                SQLQuery(
                    ("SELECT * FROM Greed_Reward WHERE Received = 0 and (Name='%s' or Account='%s');"):format(
                        unpack(
                            {
                                GetObjectName(aIndex),
                                GetObjectAccount(aIndex)
                            }
                        )
                    )
                )

                if SQLFetch() ~= 0 then
                    local ID = SQLGetNumber("Id")
                    G_Reward_Send(aIndex)
                    SQLClose()
                    SQLQuery("UPDATE Greed_Reward SET Received=1, ReceivedData=getdate() WHERE ID='%d'", {ID})
                else
                    SQLClose()
                end
            end
        end
    end
end

G_Reward_Send = function(aIndex)
    local Amount = SQLGetNumber("amount")
    local Type = SQLGetString("Type")

    if Type == "item" then
        local Index = SQLGetNumber("Index")

        if _item.exists(Index)[1] ~= nil then
            local level = SQLGetNumber("level")
            local Durability = SQLGetNumber("Durability")
            local Option1 = SQLGetNumber("Option1")
            local Option2 = SQLGetNumber("Option2")
            local Option3 = SQLGetNumber("Option3")
            local NewOption = SQLGetNumber("NewOption")
            local SetOption = SQLGetNumber("SetOption")
            local JoHOption =
                (SQLGetNumber("JoHOption") ~= 0 and (SQLGetNumber("JoHLevel") + (SQLGetNumber("JoHOption") * 16)) or 0)
            local Option380 = (SQLGetNumber("380Option") ~= 0 and 128 or 0)
            local SocketOption1 = SQLGetNumber("SocketOption1")
            local SocketOption2 = SQLGetNumber("SocketOption2")
            local SocketOption3 = SQLGetNumber("SocketOption3")
            local SocketOption4 = SQLGetNumber("SocketOption4")
            local SocketOption5 = SQLGetNumber("SocketOption5")
            local SocketOptionBonus = SQLGetNumber("SocketOptionBonus")
            local Duration = SQLGetNumber("Duration")

            if InventoryCheckSpaceByItem(aIndex, Index) == 0 then
                NoticeSend(aIndex, _strings.Reward_Free_Space_Inventory, {_item.name(Index)})
                return 1
            end

            ItemGiveEx(
                aIndex,
                Index,
                level,
                Durability,
                Option1,
                Option2,
                Option3,
                NewOption,
                SetOption,
                JoHOption,
                Option380,
                SocketOption1,
                SocketOption2,
                SocketOption3,
                SocketOption4,
                SocketOption5,
                SocketOptionBonus,
                Duration
            )
        else
            LogPrint(
                string.format(
                    "[RewardDb] %s[%s] Invalid item %s",
                    GetObjectAccount(aIndex),
                    GetObjectName(aIndex),
                    Index
                )
            )
        end
    elseif Type == "wcoinc" then
        G_RewardWCoinC(aIndex, Amount)
        NoticeSend(aIndex, _strings.Reward_WCoinC_Receive, {Amount})
    elseif Type == "wcoinp" then
        G_RewardWCoinP(aIndex, Amount)
        NoticeSend(aIndex, _strings.Reward_WCoinP_Receive, {Amount})
    elseif Type == "goblinpoint" then
        G_RewardGoblinPoint(aIndex, Amount)
        NoticeSend(aIndex, _strings.Reward_GoblinPoint_Receive, {Amount})
    elseif Type == "money" then
        G_RewardMoney(aIndex, Amount)
    elseif Type == "ruud" then
        G_RewardRuud(aIndex, Amount)
    end

    NoticeSend(aIndex, 1, SQLGetString("Comment"))
end

G_RewardDropSystem = function(aIndex, bIndex, IT, Type)
    local LoadItem = _item.exists(IT.Index)

    if LoadItem[1] == nil then
        return 1
    end

    local Level = IT.Level

    if Level == 0 then
        Level =
            IT.Option0 ~= -1 and G_ItemDropOptionRate[0][IT.Option0][math.random(#G_ItemDropOptionRate[0][IT.Option0])] or
            0
    end

    local Skill =
        IT.Option1 ~= -1 and G_ItemDropOptionRate[1][IT.Option1][math.random(#G_ItemDropOptionRate[1][IT.Option1])] or 0
    local Luck =
        IT.Option2 ~= -1 and G_ItemDropOptionRate[2][IT.Option2][math.random(#G_ItemDropOptionRate[2][IT.Option2])] or 0
    local Add =
        IT.Option3 ~= -1 and G_ItemDropOptionRate[3][IT.Option3][math.random(#G_ItemDropOptionRate[3][IT.Option3])] or 0

    local Exc = IT.Grade
    local Ancient = 0
    local Slot = {}
    Slot[0] = 255
    Slot[1] = 255
    Slot[2] = 255
    Slot[3] = 255
    Slot[4] = 255

    if Exc == 0 and IT.Option4 ~= -1 and LoadItem[7] ~= 0 then
        local Excellent = G_ItemDropOptionRate[4][IT.Option4][math.random(#G_ItemDropOptionRate[4][IT.Option4])]

        ExcOption = {}
        while (table.count(ExcOption) < Excellent and #G_ItemDropExcellentRate[IT.Index] > 0) do
            local rand = math.random(#G_ItemDropExcellentRate[IT.Index])
            if ExcOption[G_ItemDropExcellentRate[IT.Index][rand]] == nil then
                ExcOption[G_ItemDropExcellentRate[IT.Index][rand]] = G_ItemDropExcellentRate[IT.Index][rand]
            else
                table.remove(G_ItemDropExcellentRate[IT.Index], rand)
            end
        end

        for k, v in pairs(ExcOption) do
            Exc = Exc + v
        end
    end

    local AncientType = G_AncientTypeTable[IT.Index]

    if IT.Option5 ~= -1 and G_ItemDropAncientRate[IT.Index] ~= nil and AncientType ~= nil then
        local getAnc = function(t, l)
            local count = 0
            if t[1 + l] ~= nil then
                count = count + 1
            end
            if t[2 + l] ~= nil then
                count = count + 1
            end
            if t[16 + l] ~= nil then
                count = count + 1
            end

            local selected = math.random(count)

            if count > 0 then
                for k, v in pairs(t) do
                    if table.find(k, {1 + l, 2 + l, 16 + l}) ~= -1 then
                        if count == selected then
                            return k
                        end
                        count = count - 1
                    end
                end
            end

            return 0
        end

        local Anc = G_ItemDropOptionRate[5][IT.Option5][math.random(#G_ItemDropOptionRate[5][IT.Option5])]

        if Anc == 1 then
            Ancient = getAnc(AncientType, 4)
        elseif Anc == 2 then
            Ancient = getAnc(AncientType, 8)
        elseif Anc == 3 then
            Ancient = 5
        elseif Anc == 4 then
            Ancient = 9
        elseif Anc == 5 then
            Ancient = 6
        elseif Anc == 6 then
            Ancient = 10
        elseif Anc == 7 then
            Ancient = 20
        elseif Anc == 8 then
            Ancient = 24
        end
    end

    if IT.Option6 ~= -1 and (G_ItemDropSocketRate[IT.Index] ~= nil or math.floor(IT.Index % 512) > 11) then
        local Socket = G_ItemDropOptionRate[6][IT.Option6][math.random(#G_ItemDropOptionRate[6][IT.Option6])]
        Slot = {
            [1] = (Socket > 0 and 254 or 255),
            [2] = (Socket > 1 and 254 or 255),
            [3] = (Socket > 2 and 254 or 255),
            [4] = (Socket > 3 and 254 or 255),
            [5] = (Socket > 4 and 254 or 255)
        }
    end

    local Map = GetObjectMap(aIndex)
    local MapX = GetObjectMapX(aIndex)
    local MapY = GetObjectMapY(aIndex)

    local Map, MapX, MapY, Found =
        _move.check(
        {
            Map = Map,
            MapXMin = MapX - 3,
            MapXMax = MapX + 3,
            MapYMin = MapY - 3,
            MapYMax = MapY + 3
        },
        0,
        bIndex
    )

    local conf = {
        bIndex,
        Map,
        MapX,
        MapY,
        IT.Index,
        Level,
        IT.Durability,
        Skill,
        Luck,
        Add,
        Exc,
        Ancient,
        0,
        0,
        Slot[1],
        Slot[2],
        Slot[3],
        Slot[4],
        Slot[5],
        IT.Bonus,
        IT.Duration,
        bIndex
    }

    ItemDropEx(unpack(conf))
end
