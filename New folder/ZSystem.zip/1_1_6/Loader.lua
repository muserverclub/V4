_load.reload = {}
_load.start = {}
_load._end = {}
_load._loaded = {}
_load.verify = {}

BridgeFunctionAttach("OnCommandManager", "_load.reload.command")
_load.reload.command = function(aIndex, code, arg)
    if table.find(GetObjectAccount(aIndex), AdminAuthority) ~= -1 then
        if code == ReloadScriptCode then
            _load.reload.run(arg)
            return 1
        end
    end

    return 0
end

BridgeFunctionAttach("OnTimerThread", "_load.reload.thread")
_load.reload.thread = function()
    if os.time() % 3 == 0 then
        local success, Name =
            SQLQuery(
            "select Name from MSC_LOAD_SCRIPT WHERE ServerCode=%d and Status=0",
            {GetGameServerCode()},
            {"Name"}
        )
        if success ~= 0 then
            _load.reload.run(Name)
        end
    end
end

_load.reload.run = function(Script)
    if Script == "_RewardBag" then
        Reader._RewardBag()
    elseif Script == "_Data" then
        Reader._Data()
    else
        SQLQuery(
            "exec MSC_LOAD_SCRIPT_UPDATE @ServerCode=%d,@Name='%s',@Status=%d",
            {
                GetGameServerCode(),
                Script,
                2
            }
        )
        _load._end.run(Script)
        _load.start.run(Script)
    end
end

BridgeFunctionAttach("OnReadScript", "_load.start.read")
_load.start.read = function()
    local Scripts = _path.load(_path.script, ".lua")
    local ScriptOrder = {}

    for key, value in pairs(Scripts) do
        if key:lower():find("ignore") ~= 1 and key:lower():find("zsystem") == nil and key:lower():find("\\") == nil then
            for index, data in pairs(value) do
                if data:find("App%.lua") == 1 then
                    table.insert(ScriptOrder, key)
                end
            end
        end
    end

    for k, v in pairs(SetBridgeTab(ScriptOrder, true)) do
        _load.start.run(v, Scripts)
    end
end

_load.start.run = function(Script, Scripts)
    Scripts = Scripts or _path.load(_path.script, ".lua")
    local file = "App"
    local folderConfig = table.concat({Script, Path_Configs}, "\\")
    local folderCode = table.concat({Script, Path_GS}, "\\")
    if table.find(file .. ".lua", Scripts[Script] or {}) ~= -1 then
        _load._loaded[Script] = 1
        for k, v in pairs(package.loaded) do
            if k:find(Script) == 1 then
                package.loaded[k] = nil
            end
        end
        for k, v in pairs(BridgeFunctionTable) do
            for i, a in pairs(v) do
                if a.Function:find(Script) == 1 then
                    BridgeFunctionTable[k][i] = nil
                end
            end
        end
        local allow = require(table.concat({Script, file}, "\\"))

        if allow == false then
            return 1
        end
        for k, v in pairs(Scripts) do
            if k:lower() == folderConfig:lower() then
                for i, a in pairs(v) do
                    require(table.concat({folderConfig, (a:gsub("%.lua", ""))}, "\\"))
                end
            end
        end
        for k, v in pairs(Scripts) do
            if k:lower() == folderCode:lower() then
                for i, a in pairs(v) do
                    require(table.concat({folderCode, (a:gsub("%.lua", ""))}, "\\"))
                end
            end
        end
        if BridgeFunctionTable[1] ~= nil then
            for k, v in pairs(BridgeFunctionTable[1]) do
                if v.Function:find(Script) ~= nil then
                    traceback(v.Function, {})
                end
            end
        end
        if BridgeFunctionTable[113] ~= nil then
            for k, v in pairs(BridgeFunctionTable[113]) do
                if v.Function:find(Script) ~= nil then
                    traceback(v.Function, {Script})
                end
            end
        end
    end
end

BridgeFunctionAttach("OnShutScript", "_load._end.shut")
_load._end.shut = function()
    local Scripts = _path.load(_path.script, ".lua")
    local ScriptOrder = {}

    for key, value in pairs(Scripts) do
        if key:lower():find("ignore") ~= 1 and key:lower():find("zsystem") == nil and key:lower():find("\\") == nil then
            for index, data in pairs(value) do
                if data:find("App%.lua") == 1 then
                    table.insert(ScriptOrder, key)
                end
            end
        end
    end

    for k, v in pairs(table.reverse(SetBridgeTab(ScriptOrder, BridgeOrder, true))) do
        _load._end.run(v, Scripts)
    end
end

_load._end.run = function(Script)
    _load._loaded[Script] = 0

    if BridgeFunctionTable[2] ~= nil then
        for k, v in pairs(BridgeFunctionTable[2]) do
            if v.Function:find(Script) ~= nil then
                traceback(v.Function, {})
            end
        end
    end

    if BridgeFunctionTable[111] ~= nil then
        for k, v in pairs(BridgeFunctionTable[111]) do
            if v.Function:find(Script) ~= nil then
                traceback(v.Function, {Script})
            end
        end
    end

    for k, v in pairs(package.loaded) do
        if k:find(Script) == 1 then
            package.loaded[k] = nil
        end
    end
end

BridgeFunctionAttach("OnTimerThread", "_load.verify.thread")
_load.verify.thread = function()
    if _time.start({sec = 0}) == 1 then
        for k,v in pairs(License) do  
			if v.valid_until ~= -1 and v.valid_until < os.time() then
				LogColor(1, ("[%s] expired"):format(v.title))
				LogPrint(("[%s] expired"):format(v.title))
				_load._end.run(v.script_name)
			end
        end
    end
end
