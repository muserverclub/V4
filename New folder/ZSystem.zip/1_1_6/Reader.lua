Reader = {}
local readerPath = table.concat({_path.script, "ZSystem", "LOG", "DataReader.lua"}, "\\")
function Reader:Load(path)
    local this = {
        path = nil,
        file = nil,
        LineCount = 0,
        ColumnTable = {},
        ColumnReader = 1
    }

    function this:Close()
        self.file:close()
    end

    function this:GetLine(end_text)
        self.LineCount = self.LineCount + 1

        self.ColumnTable = {}

        self.ColumnReader = 1

        local LastStr = 0

        local LastCmt = 0

        local LastRow = nil

        local line = self.file:read()

        if line == nil then
            return false
        end

        for char in string.gmatch(line, ".") do
            if (char == " " or char == "	") and LastStr == 0 then
                if LastRow ~= nil then
                    table.insert(self.ColumnTable, LastRow)

                    LastRow = nil
                end
            else
                if char == "/" and LastStr == 0 then
                    if LastCmt == 0 then
                        LastCmt = 1
                    else
                        break
                    end
                else
                    if char == '"' then
                        if LastStr == 0 then
                            LastStr = 1
                        else
                            LastStr = 0
                        end
                    else
                        if LastRow == nil then
                            LastRow = char
                        else
                            LastRow = LastRow .. char
                        end
                    end
                end
            end
        end

        if LastRow ~= nil then
            table.insert(self.ColumnTable, LastRow)

            LastRow = nil
        end

        if #self.ColumnTable == 0 then
            return this:GetLine(end_text)
        elseif self.ColumnTable[1] == end_text then
            return false
        else
            return true
        end
    end

    function this:GetAsString()
        if self.ColumnReader > #self.ColumnTable then
            return ""
        else
            local value = self.ColumnTable[self.ColumnReader]

            self.ColumnReader = self.ColumnReader + 1

            return value
        end
    end

    function this:Get()
        local value = this:GetAsString()

        if value == "*" then
            return -1
        elseif tonumber(value) ~= nil then
            return tonumber(value)
        end
        return value
    end

    function this:GetAsNumber()
        if self.ColumnReader > #self.ColumnTable then
            return 0
        else
            local value = self.ColumnTable[self.ColumnReader]

            self.ColumnReader = self.ColumnReader + 1

            return (value == "*" and -1 or tonumber(value))
        end
    end

    function this:CheckCategory()
        if self.ColumnReader > #self.ColumnTable then
            return false
        elseif self.ColumnTable[(self.ColumnReader + 1)] ~= nil then
            return true
        else
            return false
        end
    end

    this.path = path

    this.file = io.open(this.path, "r")

    if this.file == nil then
        return nil
    else
        return this
    end
end

Reader.File = function(dir)
    local this = {
        [-1] = {}
    }

    local file = Reader:Load(dir)

    local category = -1

    local repet = false
    local repetcategory = false

    for i = 1, 100 do
        while file:GetLine("end") == true do
            if file:CheckCategory() == false then
                category = file:Get()
                if this[category] == nil then
                    this[category] = {}
                end
            elseif file:CheckCategory() == true then
                local count = 1
                local vars = {}
                while true do
                    local value = file:Get()
                    if value == "" then
                        break
                    end
                    value = tonumber(value) or tostring(value):gsub('\\','\\\\')
                    table.insert(vars, (_item.index(value)))
                end
                if category == -1 then
                    table.insert(this[category], vars)
                else
                    if this[category][vars[1]] == nil and repet == false then
                        this[category][vars[1]] = vars
                    elseif repet == true then
                        table.insert(this[category], vars)
                    else
                        repet = true
                        local oldtab = table.clone(this[category])
                        this[category] = {}
                        table.insert(this[category], vars)
                        for k, v in pairs(oldtab) do
                            table.insert(this[category], v)
                        end
                    end
                end
            end
        end
    end
    file:Close()

    return this
end

Reader._RewardBag = function()
    G_RewardBag = {}

    local folder = table.concat({_path.script, "ZSystem", "RewardBag"}, "\\")
    local Scripts = _path.load(folder, ".lua")

    for key, value in pairs(Scripts) do
        for index, data in pairs(value) do
            require(table.concat({"ZSystem", "RewardBag", (data:gsub(".lua", ""))}, "\\"))
        end
    end

    LogColor(2, "[Load RewardBag] success")
    SQLQuery(
        "exec MSC_LOAD_SCRIPT_UPDATE @ServerCode=%d,@Name='%s',@Status=%d",
        {
            GetGameServerCode(),
            "_RewardBag",
            1
        }
    )
end
Reader._RewardBag()

Reader._Data = function()

    _data = table.read(readerPath, "r")    
    --LogColor(1,_data["ITEM_EXCELLENTOPTIONRATE"][-1][1][1])
    if(_data == nil) then
    _data = {}

        local function read(mainPath, Ext)
            local parsed = 0
            for k, v in pairs(_path.load(mainPath, Ext)) do
                for i, a in pairs(v) do
                    local fold = k:split("\\")[1]
                    local fil = table.concat({k, a}, "\\")
                    local files = {
                        "skill\\skill.txt",
                        "monster\\monster.txt",
                        "custom\\custommonster.txt"
                    }
                    if ServerTeam == "ssemu" then
                        files = {
                            "skill\\effectlist.txt",
                            "skill\\skilllist.txt",
                            "monster\\monsterlist.txt",
                            "custom\\custommonster.txt",
                            "mapmanager.txt"
                        }
                    end
                    if
                        fold == nil or
                            table.find(
                                fold:lower(),
                                {
                                    "item"
                                }
                            ) ~= -1 or
                            table.find(fil:lower(), files) ~= -1
                    then
                        if k == "" then
                            folder = a
                        else
                            folder = table.concat({k, a}, "\\")
                        end

                        local var = string.upper(folder:match("(.+)%..+$"):gsub("\\", "_"))

                        if _data[var] == nil then
                            _data[var] = Reader.File(table.concat({mainPath, folder}, "\\"))
                            parsed = parsed + 1
                        end
                    end
                end
            end

            if ServerTeam == "ssemu" then
                _data["MONSTER_MONSTER"] = _data["MONSTER_MONSTERLIST"]
                _data["SKILL_SKILL"] = _data["SKILL_SKILLLIST"]
                _data["EFFECT"] = _data["SKILL_EFFECTLIST"]
            end

            return parsed
        end

        read(table.concat({_path.script, "ZSystem", (Path_DataOverride or "DataOverride")}, "\\"), ".txt")
        read(_path.data, ".txt")
       

        table.print(_data,readerPath,true)
    end
    _data_Load()
    _map.init()

    LogColor(2, "[Load Data] success")
    SQLQuery(
        "exec MSC_LOAD_SCRIPT_UPDATE @ServerCode=%d,@Name='%s',@Status=%d",
        {
            GetGameServerCode(),
            "_Data",
            1
        }
    )
end
Reader._Data()
