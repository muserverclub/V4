_cache = {}

_cache.dir = string.format("%s\\ZSystem\\LOG\\%s\\", _path.script, GetGameServerCode())
G_CacheDir = _cache.dir

_cache.dirDate = function()
    return _cache.dir .. os.date("%d-%m-%Y") .. "\\"
end
G_CacheDirDate = _cache.dirDate

os.execute("mkdir " .. _cache.dir)
os.execute("mkdir " .. _cache.dirDate())

_cache.set = function(Config, Id, Value, File)
    Id = Id or os.date("%c") .. "_" .. tostring(math.random(10000)):lpad(5, 0)

    local troleia1 = _cache.dir .. File .. ".log"
    local troleia2 = (type(Value) ~= "table" and Value or _json.stringify({Value}))

    ConfigSaveString(
        Config,
        Id,
        (type(Value) ~= "table" and Value or _json.stringify({Value})),
        _cache.dir .. File .. ".log"
    )
end
SetLog = _cache.set

_cache.setDate = function(Config, Id, Value, File)
    Id = Id or os.date("%X") .. "_" .. tostring(math.random(10000)):lpad(5, 0)
    ConfigSaveString(
        Config,
        Id,
        (type(Value) ~= "table" and Value or _json.stringify({Value})),
        _cache.dirDate() .. File .. ".log"
    )
end
SetLogDate = _cache.setDate

_cache.get = function(Config, Id, File)
    Id = Id or os.date("%c") .. "_" .. tostring(math.random(10000)):lpad(5, 0)
    return ConfigReadString(Config, Id, _cache.dir .. File .. ".log")
end
GetLog = _cache.get

_cache.getDate = function(Config, Id, File)
    Id = Id or os.date("%X") .. "_" .. tostring(math.random(10000)):lpad(5, 0)
    return ConfigReadString(Config, Id, _cache.dirDate() .. File .. ".log")
end
GetLogDate = _cache.getDate
