_calc = {}

_calc.setBonus = function(aIndex, ID)
    local p = 0

    for i = 0, 11, 1 do
        local t = InventoryGetItemTable(aIndex, i)

        if t ~= nil then
            local Option = G_ItemOption[t.Index]
            if Option ~= nil then
                if Option[ID] ~= nil then
                    if
                        Option[ID][1] == 0 or Option[ID][1] == 100 and t.Option1 == 1 or
                            Option[ID][1] == 101 and t.Option2 == 1 or
                            Option[ID][1] == 102 and t.Option3 > 0 or
                            math.bitAND(t.NewOption, Option[ID][1]) ~= 0
                     then
                        p = p + Option[ID][2]
                    end
                end
            end
        end
    end

    return p
end

_calc.setCombo = function(aIndex, c)
    local p = 0
    local ls = {}
    local li = {}

    for i = 0, 11, 1 do
        local t = InventoryGetItemTable(aIndex, i)

        if t ~= nil and t.Durability > 0 then
            local index = t.Index % 512

            if table.find(i, {2, 3, 4, 5, 6}) ~= -1 then
                if c.Set[index] ~= nil then
                    if ls[index] ~= nil then
                        ls[index] = ls[index] + 1
                    else
                        ls[index] = 1
                    end
                end
            else
                if c[t.Index] ~= nil then
                    if li[t.Index] ~= nil and c[t.Index].TwoCount ~= false then
                        li[t.Index] = li[t.Index] + 1
                    else
                        li[t.Index] = 1
                    end
                end
            end
        end
    end

    for k, v in pairs(li) do
        if type(c[k].Combo) == 'table' then
            for i,a in pairs(c[k].Combo) do
                if ls[a] ~= nil then
                    ls[a] = ls[a] + 1
                else
                    ls[a] = 1
                end
            end
        else
            if ls[c[k].Combo] ~= nil then
                ls[c[k].Combo] = ls[c[k].Combo] + 1
            else
                ls[c[k].Combo] = 1
            end
        end

        p = p + (c[k].Percent * v)

    end

    for k, v in pairs(ls) do
        if c.Set[k][v] ~= nil then
            p = p + c.Set[k][v]
        end
    end
    
    return p
end

-- support to old functions
G_CalcSetBonus = _calc.setBonus
G_CalcSetCombo = _calc.setCombo