math.format = function(amount)
    local formatted = amount
    while true do
        formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", "%1,%2")
        if (k == 0) then
            break
        end
    end
    return formatted
end

math.round = function(val, decimal)
    if (decimal) then
        return math.floor((val * 10 ^ decimal) + 0.5) / (10 ^ decimal)
    else
        return math.floor(val + 0.5)
    end
end

math.random = function(...)
    local arg = table.pack(...)

    if type(arg[1]) == "table" then
        return arg[1].Min + RandomGetNumber(arg[1].Max - arg[1].Min) + 1
    end
    if arg[1] ~= nil and arg[2] ~= nil then
        return arg[1] + RandomGetNumber(arg[2] - arg[1]) + 1
    end
    if type(arg[1]) == 'number' and arg[1] > 0 then
        return RandomGetNumber(arg[1]) + 1
    end
    return 0
end

math.bitAND = function(a, b) --Bitwise and
    local p, c = 1, 0
    while a > 0 and b > 0 do
        local ra, rb = a % 2, b % 2
        if ra + rb > 1 then
            c = c + p
        end
        a, b, p = (a - ra) / 2, (b - rb) / 2, p * 2
    end
    return c
end

-- Support to old functions
format_num = math.format
comma_value = math.format
round = math.round
G_RandomNumber = math.random
BitAND = math.bitAND