if _G["GetObjectGuildStatus"] == nil then
	GetObjectGuildStatus = function(aIndex)
		if GetObjectGuildNumber(aIndex) == -1 then
			return -1
		end
		
		local success, status = SQLQuery("SELECT G_Status FROM GuildMember where name = '%s'", {GetObjectName(aIndex)},{"G_Status"})
		
		status = tonumber(status)

		if status == nil then
			return -1
		else
			return status
		end
		
	end
end
