_coord.check = function(aIndex, Area)
    local Map = GetObjectMap(aIndex)
    local MapX = GetObjectMapX(aIndex)
    local MapY = GetObjectMapY(aIndex)

    if Map == Area.Map and MapX >= Area.MapXMin and MapX <= Area.MapXMax and
        MapY >= Area.MapYMin and MapY <= Area.MapYMax then return 1 end

    return 0
end

_coord.checkMult = function(aIndex, Areas)
    local Map = GetObjectMap(aIndex)
    local MapX = GetObjectMapX(aIndex)
    local MapY = GetObjectMapY(aIndex)
    for k, Area in pairs(Areas) do
        if _coord.check(aIndex,Area) == 1 then
            return k, Area
        end
    end

    return 0, nil
end

-- Support to old functions
G_CheckCoord = _coord.check
G_CheckCoordMult = _coord.checkMult
