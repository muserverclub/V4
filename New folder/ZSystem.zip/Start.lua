GetLicenseId2 = GetLicenseId
GetLicenseId = function()
	if ConfigReadNumber("GameServerInfo", "CustomerLicenseId", "DATA/GameServerInfo - Common.dat") == GetLicenseId2() then
		return GetLicenseId2()
	else
		return -1
	end
end

_download = function(type)
	type = type or "script"

	if type == "license" then
		local requestString =
			([[
				powershell (Invoke-RestMethod -Uri https://muserver.club/auth/script -ContentType "application/json" -Method POST -Headers @{'account_id'='%s'; 'license_id'='%s'; 'download_type'='%s'})
			]]):format(
			unpack({MuServerClub_Username_Id, GetLicenseId(), type})
		)

		local st = ""
		local f = assert(io.popen(requestString, "r"))
		for l in f:lines() do
			st = st .. l
		end

		f:close()

		if st:gsub(" ", ""):len() == 0 then
			LogColor(1, ("[ZSystem] not authenticated"))
			LogPrint(("[ZSystem] not authenticated"))
			LogColor(1, "Access https://github.com/muserverclub/v4 for more details")
			LogPrint("Access https://github.com/muserverclub/v4 for more details")
			return 1
		end

		License = loadstring(st)()

		CheckLicense = function(name)
			for k, v in pairs(License) do
				if v.script_name == name then

					if getMD5(MuServerClub_Username_Id .. name .. GetLicenseId()) ~= v.license then
						LogColor(1, ("[%s] not authenticated"):format(v.title))
						LogPrint(("[%s] not authenticated"):format(v.title))
						return 2, v
					end

					if v.valid_until ~= -1 and v.valid_until < os.time() then
						LogColor(1, ("[%s] expired"):format(v.title))
						LogPrint(("[%s] expired"):format(v.title))
						return 3, v
					end
					return 1, v
				end
			end

			LogColor(1, ("[%s] not found"):format(name))
			LogPrint(("[%s] not found"):format(name))
			return 4
		end
	else
		local file = table.concat({Folder_Script, "Scripts.zip"}, "\\")

		local requestString =
			([[
				powershell (Invoke-RestMethod -OutFile "%s" -Uri https://muserver.club/auth/script -ContentType "application/json" -Method POST -Headers @{'account_id'='%s'; 'license_id'='%s'; 'download_type'='%s'})
			]]):format(
			unpack({file, MuServerClub_Username_Id, GetLicenseId(), type})
		)
		local f = assert(io.popen(requestString, "r"))
		f:close()

		os.execute(("powershell Expand-Archive '%s' -DestinationPath '%s' -Force"):format(file, Folder_Script))

		os.remove(file)

		local open = io.open(table.concat({Folder_Script, "ZSystem", ZSystem_Version .. ".lua"}, "\\"), "r")
		if open == nil then
			LogColor(1, ("ZSystem/%s.lua not found"):format(ZSystem_Version))
			LogColor(1, "Access https://github.com/muserverclub/v4 for more details")
			LogPrint(("ZSystem/%s.lua not found"):format(ZSystem_Version))
			LogPrint("Access https://github.com/muserverclub/v4 for more details")
		else
			open:close()
		end
	end
end

if ServerTeam == "xteam" then
	require("ZSystem\\Curl")
	require("ZSystem\\Fetch")
end

if MuServerClub_Username_Id ~= 55 then
	_download("license")
	if DownloadScripts == true then
		_download("script")
	end
	require("ZSystem\\" .. ZSystem_Version)
	protect("GetLicenseId")
	protect("License")
	protect("GetLicense")
else
	License = {}
	CheckLicense = function(name)
		return 1
	end
	require("ZSystem\\" .. ZSystem_Version)
end
